/* profile.js
 * Player profiles: name, avatar, stats and several separate profiles.
 *
 * Each profile has its own progress (level, coins, characters, loot box prizes,
 * rewards, boss wins, save slot). This works by adding a prefix to every
 * 'frogger-*' localStorage key, so the other scripts did not need any change.
 * The first profile ("p1") uses the old keys without prefix, so progress
 * saved before profiles existed is kept.
 *
 * MUST be loaded BEFORE all other game scripts (see index.html).
 * The profile screen (profile.open) needs: player, shop, levelSystem, bossFight.
 */

var profile = (function() {

    var REG_KEY = 'frogger-profiles-v1';   // profile list: never prefixed
    var MAX_PROFILES = 5;
    var MAX_NAME = 14;

    var reg = null;

    // ---------- profile list ----------
    function loadReg() {
        try { reg = JSON.parse(window.localStorage.getItem(REG_KEY)); } catch (e) { reg = null; }
        if (!reg || !Array.isArray(reg.list) || !reg.list.length) {
            reg = { active: 'p1', list: [{ id: 'p1', name: 'Player 1', created: Date.now() }] };
        }
        if (!find(reg.active)) { reg.active = reg.list[0].id; }
    }

    function saveReg() {
        try { window.localStorage.setItem(REG_KEY, JSON.stringify(reg)); } catch (e) {}
    }

    function find(id) {
        for (var i = 0; i < reg.list.length; i++) { if (reg.list[i].id === id) { return reg.list[i]; } }
        return null;
    }

    function current() { return find(reg.active); }

    function cleanName(s) {
        return String(s || '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, MAX_NAME);
    }

    // ---------- storage prefix per profile ----------
    function prefix(id) { return id === 'p1' ? '' : id + ':'; }

    function mapKey(key) {
        if (typeof key !== 'string' || key.indexOf('frogger-') !== 0 || key === REG_KEY) { return key; }
        return prefix(reg.active) + key;
    }

    var rawDel = null;   // original removeItem (not prefixed)

    function patchStorage() {
        if (typeof Storage === 'undefined') { return; }
        var P = Storage.prototype;
        var get = P.getItem, set = P.setItem, del = P.removeItem;
        rawDel = del;
        P.getItem = function(k) { return get.call(this, this === window.localStorage ? mapKey(k) : k); };
        P.setItem = function(k, v) { return set.call(this, this === window.localStorage ? mapKey(k) : k, v); };
        P.removeItem = function(k) { return del.call(this, this === window.localStorage ? mapKey(k) : k); };
    }

    // ---------- actions ----------
    function switchTo(id) {
        if (!find(id) || id === reg.active) { return; }
        reg.active = id;
        saveReg();
        location.reload();     // every module reads its save on start
    }

    function create(name) {
        if (reg.list.length >= MAX_PROFILES) { return null; }
        name = cleanName(name) || ('Player ' + (reg.list.length + 1));
        var n = 2;
        while (find('p' + n)) { n++; }
        var p = { id: 'p' + n, name: name, created: Date.now() };
        reg.list.push(p);
        saveReg();
        return p;
    }

    function rename(name) {
        name = cleanName(name);
        if (!name) { return false; }
        current().name = name;
        saveReg();
        updateLabel();
        return true;
    }

    function remove(id) {
        if (reg.list.length < 2 || !find(id)) { return false; }
        var pre = prefix(id);
        try {
            var kill = [];
            for (var i = 0; i < localStorage.length; i++) {
                var k = localStorage.key(i);
                if (k === null || k === REG_KEY) { continue; }
                // raw key: for p1 the keys are 'frogger-*', for the others 'pN:frogger-*'
                if (pre ? k.indexOf(pre) === 0 : k.indexOf('frogger-') === 0) { kill.push(k); }
            }
            kill.forEach(function(k) { (rawDel || Storage.prototype.removeItem).call(localStorage, k); });
        } catch (e) {}
        reg.list = reg.list.filter(function(p) { return p.id !== id; });
        if (reg.active === id) { reg.active = reg.list[0].id; saveReg(); location.reload(); return true; }
        saveReg();
        return true;
    }

    // ---------- stats ----------
    function stats() {
        var chars = (window.shop ? shop.characters : []).filter(function(c) { return !c.secret; });
        var owned = chars.filter(function(c) { return shop.owns(c.id); }).length;
        var beaten = 0;
        try { beaten = Object.keys(bossFight.beaten() || {}).length; } catch (e) {}
        var bosses = 0;
        try { bosses = Object.keys(bossFight.bosses || {}).length || bossFight.bosses.length || 0; } catch (e) {}
        return [
            ['Level', window.levelSystem ? levelSystem.level : 1],
            ['Coins', window.shop ? shop.coins() : 0],
            ['Score', window.player ? player.score : 0],
            ['Characters', owned + ' / ' + chars.length],
            ['Bosses beaten', bosses ? beaten + ' / ' + bosses : beaten]
        ];
    }

    function equippedCharacter() {
        if (!window.shop || !window.player) { return null; }
        for (var i = 0; i < shop.characters.length; i++) {
            if (shop.characters[i].sprite === player.sprite) { return shop.characters[i]; }
        }
        return null;
    }

    // ---------- screen ----------
    var overlay, body, openFlag = false;

    function el(tag, cls, text) {
        var e = document.createElement(tag);
        if (cls) { e.className = cls; }
        if (text !== undefined) { e.textContent = text; }
        return e;
    }

    function button(text, fn, cls) {
        var b = el('button', 'shop-btn' + (cls ? ' ' + cls : ''), text);
        b.type = 'button';
        b.onclick = fn;
        return b;
    }

    function build() {
        var game = document.getElementById('game');
        if (!game || overlay) { return; }
        overlay = el('div');
        overlay.id = 'profileScreen';
        overlay.style.display = 'none';
        game.appendChild(overlay);
    }

    function render() {
        overlay.innerHTML = '';

        var head = el('div', 'shop-head');
        head.appendChild(el('span', '', 'Player Profile'));
        head.appendChild(button('Close', close, 'shop-close'));
        overlay.appendChild(head);

        // avatar + name
        var top = el('div', 'pf-top');
        var av = el('div', 'pf-avatar');
        var c = equippedCharacter();
        if (c) { av.appendChild(shop.makeThumb(c)); }
        top.appendChild(av);

        var who = el('div', 'pf-who');
        var input = el('input', 'pf-name');
        input.type = 'text';
        input.maxLength = MAX_NAME;
        input.value = current().name;
        input.setAttribute('aria-label', 'Player name');
        who.appendChild(input);
        var msg = el('div', 'pf-msg');
        who.appendChild(button('Save name', function() {
            if (rename(input.value)) { msg.textContent = 'Name saved!'; }
            else { msg.textContent = 'Type a name first.'; }
        }));
        who.appendChild(msg);
        top.appendChild(who);
        overlay.appendChild(top);

        // stats
        var grid = el('div', 'pf-stats');
        stats().forEach(function(s) {
            var box = el('div', 'pf-stat');
            box.appendChild(el('div', 'pf-stat-v', String(s[1])));
            box.appendChild(el('div', 'pf-stat-k', s[0]));
            grid.appendChild(box);
        });
        overlay.appendChild(grid);
        overlay.appendChild(el('div', 'shop-hint', 'Created on ' + new Date(current().created).toLocaleDateString()));

        // profile list
        overlay.appendChild(el('div', 'pf-title', 'Profiles (' + reg.list.length + '/' + MAX_PROFILES + ')'));
        var list = el('div', 'pf-list');
        reg.list.forEach(function(p) {
            var row = el('div', 'pf-row' + (p.id === reg.active ? ' active' : ''));
            row.appendChild(el('span', 'pf-row-name', (p.id === reg.active ? '★ ' : '') + p.name));
            if (p.id !== reg.active) {
                row.appendChild(button('Play', function() { switchTo(p.id); }));
            }
            if (reg.list.length > 1) {
                row.appendChild(button('Delete', function() {
                    if (confirm('Delete "' + p.name + '" and all its progress? This cannot be undone.')) {
                        remove(p.id);
                        render();
                    }
                }, 'pf-del'));
            }
            list.appendChild(row);
        });
        overlay.appendChild(list);

        if (reg.list.length < MAX_PROFILES) {
            var add = el('div', 'pf-add');
            var nn = el('input', 'pf-name');
            nn.type = 'text';
            nn.maxLength = MAX_NAME;
            nn.placeholder = 'New profile name';
            add.appendChild(nn);
            add.appendChild(button('+ New profile', function() {
                var p = create(nn.value);
                if (p) { switchTo(p.id); }
            }));
            overlay.appendChild(add);
        }
    }

    function open() {
        if (!overlay) { build(); }
        if (window.shop && shop.isOpen()) { shop.close(); }
        render();
        overlay.style.display = 'block';
        openFlag = true;
    }

    function close() {
        if (overlay) { overlay.style.display = 'none'; }
        openFlag = false;
    }

    function toggle() { if (openFlag) { close(); } else { open(); } }

    function updateLabel() {
        var e = document.getElementById('profileName');
        if (e && reg) { e.textContent = '👤 ' + current().name; }
    }

    // ---------- start ----------
    loadReg();
    patchStorage();
    document.addEventListener('DOMContentLoaded', function() {
        updateLabel();
        if (window.shop && shop.onChange) { shop.onChange(function() { if (openFlag) { render(); } }); }
    });

    return {
        open: open,
        close: close,
        toggle: toggle,
        isOpen: function() { return openFlag; },
        name: function() { return current().name; },
        id: function() { return reg.active; },
        list: function() { return reg.list.slice(); },
        rename: rename,
        create: create,
        switchTo: switchTo
    };
})();
