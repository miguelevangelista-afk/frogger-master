/* shop.js
 * Shop: earn coins by crossing the road, spend them on characters (tab 1),
 * on loot boxes (tab 2, see boxes.js) or collect free rewards (tab 3, see rewards.js).
 *
 * Characters can be BOUGHT here with coins, or WON from loot boxes
 * and treasure chests (see shop.pickDrop / shop.unlock).
 *
 * To add a new character:
 *   - plain picture : add a line with  sprite: 'images/your-image.png'
 *   - animated      : add a line with  sprite: 'images/chars/NAME.png'  and  sheet: {...}
 *     A sheet is 4 rows (down, left, right, up) of 101x171 frames, up to 4 frames per row.
 *     sheet tells how many frames each row really has, e.g. { down: 4, left: 4, right: 4, up: 4 }.
 *     (A row with 1 frame is animated automatically with a little bounce.)
 *
 * Depends on: player (app.js), Resources (resources.js).
 */

var shop = (function() {

    var COINS_PER_CROSSING = 10;   // coins earned each time you reach the water

    var CELL_W = 101, CELL_H = 171;                       // one frame of an animated character sheet
    var FEET_IN_CELL = 146;                               // y of the character's feet inside a frame
    var DIR_ROW = { down: 0, left: 1, right: 2, up: 3 };  // row of each direction in a sheet

    var RARITIES = {
        common:    { name: 'Common',    color: '#9ab0c4', weight: 50 },
        rare:      { name: 'Rare',      color: '#3fd66f', weight: 28 },
        epic:      { name: 'Epic',      color: '#c86bff', weight: 15 },
        legendary: { name: 'Legendary', color: '#ffb02e', weight: 7 }
    };

    // price: 0 = free, owned from the start
    var CHARACTERS = [
        { id: 'boy',        name: 'Boy',        sprite: 'images/char-boy.png',          price: 0,   rarity: 'common' },
        { id: 'cat-girl',   name: 'Cat Girl',   sprite: 'images/char-cat-girl.png',     price: 30,  rarity: 'common' },
        { id: 'horn-girl',  name: 'Horn Girl',  sprite: 'images/char-horn-girl.png',    price: 60,  rarity: 'common' },
        { id: 'pink-girl',  name: 'Pink Girl',  sprite: 'images/char-pink-girl.png',    price: 90,  rarity: 'rare' },
        { id: 'princess',   name: 'Princess',   sprite: 'images/char-princess-girl.png', price: 150, rarity: 'epic' },
        { id: 'dino',       name: 'Hard Hat Dino', sprite: 'images/char-dino.png',      price: 120, rarity: 'rare' },

        // ---- animated characters ----
        { id: 'sheep',    name: 'Fluffy Sheep',   sprite: 'images/chars/sheep.png',    sheet: { down: 4, left: 4, right: 4, up: 4 }, price: 40,  rarity: 'common' },
        { id: 'cow',      name: 'Cow',            sprite: 'images/chars/cow.png',      sheet: { down: 4, left: 4, right: 4, up: 4 }, price: 50,  rarity: 'common' },
        { id: 'pompom',   name: 'Pudding Pup',    sprite: 'images/chars/pompom.png',   sheet: { down: 4, left: 4, right: 4, up: 4 }, price: 75,  rarity: 'common' },
        { id: 'shiba',    name: 'Shiba',          sprite: 'images/chars/shiba.png',    sheet: { down: 4, left: 4, right: 4, up: 4 }, price: 95,  rarity: 'rare' },
        { id: 'horse',    name: 'Little Deer',    sprite: 'images/chars/horse.png',    sheet: { down: 4, left: 4, right: 4, up: 4 }, price: 110, rarity: 'rare' },
        { id: 'frog',     name: 'Purple Frog',    sprite: 'images/chars/frog.png',     sheet: { down: 1, left: 1, right: 1, up: 1 }, price: 130, rarity: 'rare' },
        { id: 'pinkgirl', name: 'Rock Girl',      sprite: 'images/chars/pinkgirl.png', sheet: { down: 1, left: 2, right: 2, up: 1 }, price: 160, rarity: 'epic' },
        { id: 'nun',      name: 'Sister',         sprite: 'images/chars/nun.png',      sheet: { down: 3, left: 3, right: 3, up: 3 }, price: 190, rarity: 'epic' },
        { id: 'turtle',   name: 'Shell Dragon',   sprite: 'images/chars/turtle.png',   sheet: { down: 2, left: 2, right: 2, up: 2 }, price: 240, rarity: 'epic' },
        { id: 'knight',   name: 'Iron Knight',    sprite: 'images/chars/knight.png',   sheet: { down: 2, left: 3, right: 3, up: 2 }, price: 300, rarity: 'legendary' },
        { id: 'hood',     name: 'Red Hood',       sprite: 'images/chars/hood.png',     sheet: { down: 4, left: 4, right: 4, up: 4 }, price: 400, rarity: 'legendary' },

        { id: 'snorlax', name: 'Snorlax ★ Secret', sprite: 'images/snorlax/frame-0.png', price: 999999, secret: true, rarity: 'legendary' }
    ];

    var KEY = 'frogger-shop-v1';
    var state = { coins: 0, owned: ['boy'], equipped: 'boy' };
    var isOpenFlag = false;
    var overlay, grid, coinsLabel, message, messageTimer;
    var charView, boxView, rewardView, tabButtons = {};
    var coinListeners = [];     // functions called whenever the coin balance changes
    var changeListeners = [];   // functions called whenever the owned characters change
    var thumbs = [];            // animated thumbnails currently on screen
    var thumbTimer = null;

    // ---------- saving ----------
    function load() {
        try {
            var raw = window.localStorage.getItem(KEY);
            if (raw) {
                var s = JSON.parse(raw);
                if (typeof s.coins === 'number') { state.coins = s.coins; }
                if (Array.isArray(s.owned)) { state.owned = s.owned; }
                if (typeof s.equipped === 'string') { state.equipped = s.equipped; }
            }
        } catch (e) { /* storage unavailable: just start fresh */ }
        if (state.owned.indexOf('boy') === -1) { state.owned.push('boy'); }
    }

    function save() {
        try { window.localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
    }

    // ---------- helpers ----------
    function find(id) {
        for (var i = 0; i < CHARACTERS.length; i++) {
            if (CHARACTERS[i].id === id) { return CHARACTERS[i]; }
        }
        return null;
    }

    function owns(id) { return state.owned.indexOf(id) !== -1; }

    function rarityOf(c) { return RARITIES[c.rarity] || RARITIES.common; }

    function ownedCount() { return state.owned.length; }

    // Set the player's sprite once the image is ready (new images load lazily)
    function applySprite(c) {
        Resources.load(c.sprite);
        (function wait() {
            if (Resources.get(c.sprite)) {
                player.sprite = c.sprite;
                player.charDef = c.sheet ? c : null;   // animated characters are drawn from their sheet
            }
            else { setTimeout(wait, 50); }
        })();
    }

    function updateCoinsLabel() {
        var text = '🪙 ' + state.coins;
        var el = document.getElementById('coins');
        if (el) { el.textContent = 'Coins ' + state.coins; }
        if (coinsLabel) { coinsLabel.textContent = text; }
        coinListeners.forEach(function(f) { f(state.coins); });
    }

    function notifyChange() { changeListeners.forEach(function(f) { f(); }); }

    function flash(text) {
        if (!message) { return; }
        message.textContent = text;
        clearTimeout(messageTimer);
        messageTimer = setTimeout(function() { message.textContent = ''; }, 2200);
    }

    // ---------- animated thumbnails ----------
    // Draws one frame of an animated character into any canvas context.
    function drawFrame(g, c, dir, frame, dx, dy, w, h) {
        var img = Resources.get(c.sprite);
        if (!img) { return false; }
        var n = c.sheet[dir] || 1;
        g.drawImage(img, (frame % n) * CELL_W, DIR_ROW[dir] * CELL_H, CELL_W, CELL_H, dx, dy, w, h);
        return true;
    }

    // Creates a small canvas showing a character. Animated characters move:
    // they breathe/blink by themselves, and walk when the mouse is over them.
    function makeThumb(c) {
        var cv = document.createElement('canvas');
        cv.width = CELL_W; cv.height = 112;
        cv.className = 'shop-thumb';
        if (c.sheet) {
            Resources.load(c.sprite);
            var t = { cv: cv, c: c, walking: false, born: Date.now() };
            cv.onmouseenter = function() { t.walking = true; };
            cv.onmouseleave = function() { t.walking = false; };
            cv.ontouchstart = function() { t.walking = true; setTimeout(function() { t.walking = false; }, 1500); };
            thumbs.push(t);
            drawThumb(t);
            startThumbs();
        } else {
            var img = new Image();
            img.onload = function() {
                var g = cv.getContext('2d');
                g.drawImage(img, 0, 40, CELL_W, 112, 0, 0, CELL_W, 112);
            };
            img.src = c.sprite;
            if (c.sprite.indexOf('snorlax') !== -1) {
                img.onload = function() { cv.getContext('2d').drawImage(img, 6, 0, 88, 107); };
            }
        }
        return cv;
    }

    function drawThumb(t) {
        var g = t.cv.getContext('2d');
        var now = (Date.now() - t.born) / 1000;
        g.clearRect(0, 0, CELL_W, 112);
        var dir = t.walking ? 'right' : 'down';
        var n = t.c.sheet[dir] || 1;
        var frame = t.walking ? Math.floor(now * 9) % n : (n > 1 ? Math.floor(now * 3) % n : 0);
        var hop = t.walking ? -Math.abs(Math.sin(now * 18)) * 4 : 0;
        var squash = t.walking ? 1 : 1 + Math.sin(now * 3) * 0.025;
        g.save();
        g.translate(CELL_W / 2, 106);                     // feet position inside the thumbnail
        g.scale(1 / squash, squash);
        drawFrame(g, t.c, dir, frame, -CELL_W / 2, -FEET_IN_CELL + hop, CELL_W, CELL_H);
        g.restore();
    }

    function tickThumbs() {
        thumbs = thumbs.filter(function(t) { return t.cv.isConnected; });
        thumbs.forEach(drawThumb);
        if (!thumbs.length) { clearInterval(thumbTimer); thumbTimer = null; }
    }

    function startThumbs() {
        if (!thumbTimer) { thumbTimer = setInterval(tickThumbs, 90); }
    }

    // ---------- actions ----------
    function addCoins(n) {
        state.coins += n;
        save();
        updateCoinsLabel();
        if (isOpenFlag && charView.style.display !== 'none') { renderGrid(); }
    }

    // Take coins away (used by loot boxes). Returns false if there are not enough.
    function spend(n) {
        if (!(n >= 0) || state.coins < n) { return false; }
        state.coins -= n;
        save();
        updateCoinsLabel();
        if (isOpenFlag && charView.style.display !== 'none') { renderGrid(); }
        return true;
    }

    function equip(id) {
        var c = find(id);
        if (!c || !owns(id)) { return; }
        state.equipped = id;
        save();
        applySprite(c);
        if (isOpenFlag) { renderGrid(); }
    }

    function buy(id) {
        var c = find(id);
        if (!c || owns(id)) { return; }
        if (state.coins < c.price) { flash('Not enough coins!'); return; }
        state.coins -= c.price;
        state.owned.push(id);
        save();
        updateCoinsLabel();
        equip(id);
        flash(c.name + ' unlocked!');
        notifyChange();
    }

    // Give a character for free (used by loot boxes / rewards). Does not change who you play.
    function unlock(id) {
        var c = find(id);
        if (!c || owns(id)) { return false; }
        state.owned.push(id);
        save();
        if (isOpenFlag) { renderGrid(); }
        notifyChange();
        return true;
    }

    // Choose a random character you do not own yet (rarer ones are less likely).
    // Does NOT unlock it: call unlock(id) when the prize is handed out.
    function pickDrop() {
        var pool = CHARACTERS.filter(function(c) { return !c.secret && !owns(c.id); });
        if (!pool.length) { return null; }
        var total = 0, i;
        pool.forEach(function(c) { total += rarityOf(c).weight; });
        var r = Math.random() * total;
        for (i = 0; i < pool.length; i++) {
            r -= rarityOf(pool[i]).weight;
            if (r < 0) { return pool[i]; }
        }
        return pool[pool.length - 1];
    }

    function unlockSecret(id) {
        if (!find(id) || owns(id)) return false;
        state.owned.push(id);
        save();
        if (isOpenFlag) renderGrid();
        equip(id);
        flash('SECRET CHARACTER UNLOCKED!');
        notifyChange();
        return true;
    }

    // "Change Player" button: cycle through the characters you own
    function cycle() {
        var ownedList = CHARACTERS.filter(function(c) { return owns(c.id); });
        var idx = 0;
        for (var i = 0; i < ownedList.length; i++) {
            if (ownedList[i].id === state.equipped) { idx = i; }
        }
        equip(ownedList[(idx + 1) % ownedList.length].id);
    }

    // ---------- UI ----------
    function renderGrid() {
        grid.innerHTML = '';
        thumbs = [];
        CHARACTERS.forEach(function(c) {
            var card = document.createElement('div');
            card.className = 'shop-card';
            var rar = rarityOf(c);
            card.style.borderColor = rar.color;

            card.appendChild(makeThumb(c));

            var name = document.createElement('div');
            name.className = 'shop-name';
            name.textContent = c.name + (c.secret && !owns(c.id) ? ' (Loot box only)' : '');
            card.appendChild(name);

            var tag = document.createElement('div');
            tag.className = 'shop-rarity';
            tag.style.color = rar.color;
            tag.textContent = rar.name + (c.sheet ? ' · animated' : '');
            card.appendChild(tag);

            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'shop-btn';

            if (state.equipped === c.id) {
                btn.textContent = 'Equipped';
                btn.disabled = true;
            } else if (owns(c.id)) {
                btn.textContent = 'Equip';
                btn.onclick = function() { equip(c.id); };
            } else if (c.secret) {
                btn.textContent = 'Locked 🔒';
                btn.disabled = true;
                btn.title = 'Win Snorlax from a loot box!';
            } else {
                btn.textContent = 'Buy 🪙 ' + c.price;
                if (state.coins < c.price) { btn.className += ' shop-locked'; }
                btn.onclick = function() { buy(c.id); };
            }
            card.appendChild(btn);
            grid.appendChild(card);
        });
    }

    function buildOverlay() {
        var game = document.getElementById('game');
        overlay = document.createElement('div');
        overlay.id = 'shop';
        overlay.style.display = 'none';

        var head = document.createElement('div');
        head.className = 'shop-head';

        var title = document.createElement('span');
        title.textContent = 'Shop';
        head.appendChild(title);

        coinsLabel = document.createElement('span');
        coinsLabel.className = 'shop-coins';
        head.appendChild(coinsLabel);

        var close = document.createElement('button');
        close.type = 'button';
        close.className = 'shop-btn shop-close';
        close.textContent = 'Close';
        close.onclick = closeShop;
        head.appendChild(close);

        overlay.appendChild(head);

        // tabs: Characters | Loot Boxes | Rewards
        var tabs = document.createElement('div');
        tabs.className = 'shop-tabs';
        [['characters', 'Characters'], ['boxes', 'Loot Boxes'], ['rewards', 'Rewards']].forEach(function(t) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'shop-btn shop-tab';
            b.textContent = t[1];
            b.onclick = function() { showTab(t[0]); };
            tabButtons[t[0]] = b;
            tabs.appendChild(b);
        });
        overlay.appendChild(tabs);

        charView = document.createElement('div');
        var hint = document.createElement('div');
        hint.className = 'shop-hint';
        hint.textContent = 'Buy characters with coins, or win them from Loot Boxes and treasure chests!';
        charView.appendChild(hint);
        grid = document.createElement('div');
        grid.className = 'shop-grid';
        charView.appendChild(grid);
        message = document.createElement('div');
        message.className = 'shop-message';
        charView.appendChild(message);
        overlay.appendChild(charView);

        boxView = document.createElement('div');   // filled by boxes.js
        boxView.id = 'boxView';
        boxView.style.display = 'none';
        overlay.appendChild(boxView);

        rewardView = document.createElement('div');   // filled by rewards.js
        rewardView.id = 'rewardView';
        rewardView.style.display = 'none';
        overlay.appendChild(rewardView);

        game.appendChild(overlay);
    }

    function showTab(name) {
        charView.style.display = name === 'characters' ? 'block' : 'none';
        boxView.style.display = name === 'boxes' ? 'block' : 'none';
        rewardView.style.display = name === 'rewards' ? 'block' : 'none';
        ['characters', 'boxes', 'rewards'].forEach(function(k) {
            tabButtons[k].className = 'shop-btn shop-tab' + (k === name ? ' active' : '');
        });
        if (name === 'boxes' && window.boxes) { window.boxes.refresh(); }
        if (name === 'rewards' && window.rewards) { window.rewards.refresh(); }
        if (name === 'characters') { renderGrid(); }
    }

    function showGameArea() {
        var g = document.getElementById('game');
        if (g && g.scrollIntoView) { g.scrollIntoView({ block: 'start', behavior: 'smooth' }); }
    }

    function openShop(tab) {
        isOpenFlag = true;
        overlay.style.display = 'block';
        showGameArea();   // on phones the buttons are below the game: bring the panel into view
        showTab(tab === 'boxes' || tab === 'rewards' ? tab : 'characters');
        updateCoinsLabel();
    }

    function closeShop() {
        isOpenFlag = false;
        overlay.style.display = 'none';
    }

    function toggle() { if (isOpenFlag) { closeShop(); } else { openShop('characters'); } }

    // ---------- start up ----------
    load();
    buildOverlay();
    updateCoinsLabel();

    var saved = find(state.equipped) || CHARACTERS[0];
    if (owns(saved.id)) { applySprite(saved); }

    document.addEventListener('keyup', function(e) {
        if (e.keyCode === 27 && isOpenFlag) { closeShop(); }   // Esc closes the shop
    });

    return {
        characters: CHARACTERS,
        rarities: RARITIES,
        coinsPerCrossing: COINS_PER_CROSSING,
        isOpen: function() { return isOpenFlag; },
        toggle: toggle,
        open: openShop,
        close: closeShop,
        addCoins: addCoins,
        spend: spend,
        coins: function() { return state.coins; },
        onCoins: function(f) { coinListeners.push(f); },
        onChange: function(f) { changeListeners.push(f); },
        boxView: boxView,
        rewardView: rewardView,
        cycle: cycle,
        owns: owns,
        ownedCount: ownedCount,
        find: find,
        pickDrop: pickDrop,
        unlock: unlock,
        unlockSecret: unlockSecret,
        makeThumb: makeThumb,
        drawFrame: drawFrame
    };
})();
