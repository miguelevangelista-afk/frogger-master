/* boss.js
 * Boss fights. A boss appears when you reach its level (25 = Ogre, 50 = Golem).
 * You can also challenge any unlocked boss with the "Boss Fight" button.
 *
 * How the fight works (real time):
 *  - ATTACK (button, Space or J): hit the boss. Short cooldown.
 *  - The boss winds up (a "!" shows). Press DODGE (button, Shift or K) in time, or you take damage.
 *  - Boss HP at 0 = victory: coins + XP, saved. Your HP at 0 = defeat, try again any time.
 *
 * Depends on: levelSystem (level.js), shop (shop.js). Add more bosses to BOSSES below.
 */
var bossFight = (function() {

    var BOSSES = [
        { id: 'ogre',  name: 'Forest Ogre',  level: 25, hp: 300,  dmg: 14, windup: 0.9, gap: 2.2,
          idle: 'images/boss/ogre-idle.png', attack: 'images/boss/ogre-attack.png', hurt: 'images/boss/ogre-hurt.png',
          scale: 4, coins: 500,  xp: 150 },
        { id: 'golem', name: 'Stone Golem',  level: 50, hp: 800,  dmg: 22, windup: 0.75, gap: 1.8,
          idle: 'images/boss/golem.png', attack: 'images/boss/golem.png', hurt: 'images/boss/golem.png',
          scale: 0.6, coins: 1500, xp: 400 }
    ];
    var KEY = 'frogger-boss-v1';
    var PLAYER_HP = 100, ATTACK_CD = 0.45, DODGE_TIME = 0.5;

    var beaten = {};
    var open = false, f = null, timer = null, overlay, els = {};

    function load() { try { beaten = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { beaten = {}; } }
    function save() { try { localStorage.setItem(KEY, JSON.stringify(beaten)); } catch (e) {} }
    function level() { return window.levelSystem ? levelSystem.level : 1; }
    function byId(id) { for (var i = 0; i < BOSSES.length; i++) { if (BOSSES[i].id === id) { return BOSSES[i]; } } return null; }

    function build() {
        overlay = document.createElement('div');
        overlay.id = 'bossOverlay';
        overlay.hidden = true;
        overlay.innerHTML =
            '<div class="bf-box">' +
            '<div class="bf-title" id="bfTitle"></div>' +
            '<div class="bf-bar"><div class="bf-fill bf-boss" id="bfBossHp"></div></div>' +
            '<div class="bf-stage"><img id="bfBoss" alt="" class="bf-sprite"><div id="bfWarn" class="bf-warn">!</div><div id="bfDmg" class="bf-dmg"></div></div>' +
            '<div class="bf-bar bf-small"><div class="bf-fill bf-me" id="bfMeHp"></div></div>' +
            '<div class="bf-msg" id="bfMsg"></div>' +
            '<div class="bf-btns">' +
            '<button type="button" id="bfAtk" class="bf-btn"><img src="images/boss/btn-sword.png" alt=""> Attack</button>' +
            '<button type="button" id="bfDodge" class="bf-btn bf-dodge">&#128737; Dodge</button>' +
            '</div>' +
            '<button type="button" id="bfClose" class="bf-close">Run away</button>' +
            '</div>';
        document.body.appendChild(overlay);
        ['bfTitle', 'bfBossHp', 'bfBoss', 'bfWarn', 'bfDmg', 'bfMeHp', 'bfMsg', 'bfAtk', 'bfDodge', 'bfClose'].forEach(function(id) { els[id] = document.getElementById(id); });
        els.bfAtk.addEventListener('pointerdown', function(e) { e.preventDefault(); attack(); });
        els.bfDodge.addEventListener('pointerdown', function(e) { e.preventDefault(); dodge(); });
        els.bfClose.addEventListener('click', function() { endFight(false, true); });
        document.addEventListener('keydown', function(e) {
            if (!open) { return; }
            var k = e.key;
            if (k === ' ' || k === 'j' || k === 'J') { e.preventDefault(); attack(); }
            else if (k === 'Shift' || k === 'k' || k === 'K') { e.preventDefault(); dodge(); }
            else if (k === 'Escape') { endFight(false, true); }
        });
    }

    function say(t) { els.bfMsg.textContent = t; }
    function setSprite(src) { els.bfBoss.src = src; }

    function draw() {
        els.bfBossHp.style.width = Math.max(0, f.bossHp / f.boss.hp * 100) + '%';
        els.bfMeHp.style.width = Math.max(0, f.myHp / PLAYER_HP * 100) + '%';
    }

    // practice = true skips the level requirement and gives no rewards (for testing)
    function start(id, practice) {
        var b = byId(id);
        if (!b || open) { return false; }
        if (!practice && level() < b.level) { return false; }
        if (!overlay) { build(); }
        f = { practice: !!practice, boss: b, bossHp: b.hp, myHp: PLAYER_HP, cd: 0, dodge: 0, t: b.gap, wind: 0, hurt: 0, over: false };
        open = true;
        overlay.hidden = false;
        var g = document.getElementById('game');
        if (g && g.scrollIntoView) { g.scrollIntoView({ block: 'start', behavior: 'smooth' }); }
        els.bfTitle.textContent = b.name + '  (Lv ' + b.level + ')' + (practice ? '  - PRACTICE' : '');
        els.bfBoss.style.width = Math.round(b.scale * (b.id === 'ogre' ? 65 : 452)) + 'px';
        els.bfBoss.className = 'bf-sprite' + (b.id === 'ogre' ? ' px' : '');
        setSprite(b.idle);
        els.bfWarn.style.display = 'none';
        say('Fight! Attack, and dodge when you see the "!"');
        draw();
        var last = Date.now();
        timer = setInterval(function() { var n = Date.now(); tick((n - last) / 1000); last = n; }, 50);
        return true;
    }

    function dmgPopup(txt, cls) {
        els.bfDmg.textContent = txt;
        els.bfDmg.className = 'bf-dmg show ' + (cls || '');
        setTimeout(function() { if (els.bfDmg) { els.bfDmg.className = 'bf-dmg'; } }, 450);
    }

    function attack() {
        if (!open || !f || f.over || f.cd > 0) { return; }
        f.cd = ATTACK_CD;
        var base = 10 + Math.floor(level() / 5);
        var crit = Math.random() < 0.15;
        var d = Math.round(base * (0.8 + Math.random() * 0.5) * (crit ? 2 : 1));
        f.bossHp -= d;
        f.hurt = 0.2;
        setSprite(f.boss.hurt);
        dmgPopup((crit ? 'CRIT ' : '-') + d, crit ? 'crit' : '');
        draw();
        if (f.bossHp <= 0) { endFight(true); }
    }

    function dodge() {
        if (!open || !f || f.over) { return; }
        f.dodge = DODGE_TIME;
        els.bfDodge.classList.add('on');
        setTimeout(function() { els.bfDodge.classList.remove('on'); }, DODGE_TIME * 1000);
    }

    function tick(dt) {
        if (!f || f.over) { return; }
        if (f.cd > 0) { f.cd -= dt; }
        if (f.dodge > 0) { f.dodge -= dt; }
        if (f.hurt > 0) { f.hurt -= dt; if (f.hurt <= 0 && f.wind <= 0) { setSprite(f.boss.idle); } }
        if (f.wind > 0) {
            f.wind -= dt;
            if (f.wind <= 0) {                       // the hit lands
                els.bfWarn.style.display = 'none';
                if (f.dodge > 0) {
                    say('Dodged!');
                } else {
                    f.myHp -= f.boss.dmg;
                    say('Ouch! -' + f.boss.dmg);
                    els.bfBoss.classList.add('shake');
                    setTimeout(function() { els.bfBoss.classList.remove('shake'); }, 250);
                }
                setSprite(f.boss.idle);
                f.t = f.boss.gap * (0.8 + Math.random() * 0.5);
                draw();
                if (f.myHp <= 0) { endFight(false); }
            }
        } else {
            f.t -= dt;
            if (f.t <= 0) {
                f.wind = f.boss.windup;
                f.dodge = 0;
                els.bfWarn.style.display = 'block';
                setSprite(f.boss.attack);
                say('Watch out!');
            }
        }
    }

    function endFight(won, ranAway) {
        if (!f) { return; }
        f.over = true;
        clearInterval(timer);
        els.bfWarn.style.display = 'none';
        var b = f.boss;
        if (won && f.practice) {
            say('VICTORY! (practice: no reward)');
            els.bfClose.textContent = 'Close';
        } else if (won) {
            var first = !beaten[b.id];
            beaten[b.id] = true; save();
            var coins = first ? b.coins : Math.round(b.coins / 5);
            if (window.shop) { shop.addCoins(coins); }
            if (window.levelSystem) { levelSystem.addXp(first ? b.xp : Math.round(b.xp / 5)); }
            say('VICTORY! +' + coins + ' coins' + (first ? ' (first win bonus)' : ''));
            els.bfClose.textContent = 'Close';
        } else if (ranAway) {
            close(); return;
        } else {
            say('Defeated... train up and try again!');
            els.bfClose.textContent = 'Close';
        }
        els.bfClose.onclick = close;
    }

    function close() {
        open = false; f = null;
        if (overlay) { overlay.hidden = true; }
        if (els.bfClose) { els.bfClose.textContent = 'Run away'; els.bfClose.onclick = null; els.bfClose.addEventListener('click', function() { endFight(false, true); }); }
        updateButton();
    }

    // called by the level system after a level-up
    function check(lvl) {
        for (var i = 0; i < BOSSES.length; i++) {
            if (BOSSES[i].level === lvl && !beaten[BOSSES[i].id]) {
                setTimeout(function(id) { return function() { start(id); }; }(BOSSES[i].id), 3000);
            }
        }
    }

    // the menu button fights the highest unlocked boss
    function fightNext() {
        var pick = null;
        BOSSES.forEach(function(b) { if (level() >= b.level) { pick = b; } });
        if (!pick) { alert('The first boss (Forest Ogre) appears at level ' + BOSSES[0].level + '.'); return; }
        start(pick.id);
    }

    function updateButton() {
        var b = document.getElementById('openBoss');
        if (b) { b.textContent = level() >= BOSSES[0].level ? 'Boss Fight' : 'Boss (Lv ' + BOSSES[0].level + ')'; }
    }

    load();
    setTimeout(updateButton, 0);
    return { bosses: BOSSES, start: start, check: check, fightNext: fightNext, isOpen: function() { return open; }, beaten: function() { return beaten; } };
})();
