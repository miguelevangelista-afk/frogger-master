/* rewards.js
 * Reward system (third tab of the shop):
 *   - Daily reward: come back every day to build a 7-day streak.
 *     Day 7 gives a free new character (or a big coin bonus if you own them all).
 *   - Missions: cross the road, level up, open boxes, collect characters.
 *     Each finished mission can be claimed once for coins.
 *
 * Everything is saved in the browser (localStorage). Nothing here uses real money.
 * To add a mission, add one line to MISSIONS. To change the daily prizes, edit DAILY.
 * Depends on: shop (shop.js). Optional: levelSystem (level.js).
 */

var rewards = (function() {

    var KEY = 'frogger-rewards-v1';

    // coins for each day of the streak; 'character' = a free new character
    var DAILY = [20, 30, 40, 50, 60, 80, 'character'];
    var DAILY_FALLBACK = 200;      // day 7 when there is no character left to win

    var MISSIONS = [
        { id: 'cross10',  name: 'Cross the road 10 times',  coins: 30,  goal: 10,  value: function() { return state.crossings; } },
        { id: 'cross50',  name: 'Cross the road 50 times',  coins: 100, goal: 50,  value: function() { return state.crossings; } },
        { id: 'cross150', name: 'Cross the road 150 times', coins: 250, goal: 150, value: function() { return state.crossings; } },
        { id: 'level5',   name: 'Reach level 5',            coins: 80,  goal: 5,   value: function() { return level(); } },
        { id: 'level10',  name: 'Reach level 10',           coins: 200, goal: 10,  value: function() { return level(); } },
        { id: 'box5',     name: 'Open 5 boxes or chests',   coins: 60,  goal: 5,   value: function() { return state.boxes; } },
        { id: 'box25',    name: 'Open 25 boxes or chests',  coins: 200, goal: 25,  value: function() { return state.boxes; } },
        { id: 'own5',     name: 'Own 5 characters',         coins: 100, goal: 5,   value: function() { return shop.ownedCount(); } },
        { id: 'own10',    name: 'Own 10 characters',        coins: 250, goal: 10,  value: function() { return shop.ownedCount(); } },
        { id: 'own15',    name: 'Own 15 characters',        coins: 500, goal: 15,  value: function() { return shop.ownedCount(); } }
    ];

    var state = { crossings: 0, boxes: 0, streak: 0, lastClaim: '', claimed: {} };
    var root, toastTimer, badge;

    function level() { return window.levelSystem ? (levelSystem.level | 0) : 1; }

    // ---------- saving ----------
    function load() {
        try {
            var s = JSON.parse(window.localStorage.getItem(KEY));
            if (s) {
                state.crossings = s.crossings | 0;
                state.boxes = s.boxes | 0;
                state.streak = s.streak | 0;
                state.lastClaim = typeof s.lastClaim === 'string' ? s.lastClaim : '';
                state.claimed = s.claimed && typeof s.claimed === 'object' ? s.claimed : {};
            }
        } catch (e) {}
    }
    function save() {
        try { window.localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
    }

    // ---------- daily streak ----------
    function dayString(offsetDays) {
        var d = new Date();
        d.setDate(d.getDate() + (offsetDays || 0));
        return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
    }

    function claimedToday() { return state.lastClaim === dayString(0); }

    // which day of the 7-day cycle you would claim now (1..7)
    function nextDay() {
        if (state.lastClaim === dayString(-1)) { return (state.streak % DAILY.length) + 1; }
        if (claimedToday()) { return state.streak; }
        return 1;                                   // a day was missed: the streak starts again
    }

    function claimDaily() {
        if (claimedToday()) { return; }
        var day = nextDay();
        var prize = DAILY[day - 1];
        var msg;
        if (prize === 'character') {
            var c = shop.pickDrop();
            if (c) { shop.unlock(c.id); msg = 'Day ' + day + ': NEW CHARACTER ' + c.name + '!'; }
            else { shop.addCoins(DAILY_FALLBACK); msg = 'Day ' + day + ': +' + DAILY_FALLBACK + ' coins!'; }
        } else {
            shop.addCoins(prize);
            msg = 'Day ' + day + ': +' + prize + ' coins!';
        }
        state.streak = day;
        state.lastClaim = dayString(0);
        save();
        toast(msg);
        refresh();
    }

    // ---------- missions ----------
    function missionDone(m) { return m.value() >= m.goal; }

    function claimMission(m) {
        if (state.claimed[m.id] || !missionDone(m)) { return; }
        state.claimed[m.id] = true;
        shop.addCoins(m.coins);
        save();
        toast('Mission complete: +' + m.coins + ' coins!');
        refresh();
    }

    // anything waiting to be claimed? (used for the red dot on the Rewards button)
    function pending() {
        var n = claimedToday() ? 0 : 1;
        MISSIONS.forEach(function(m) { if (!state.claimed[m.id] && missionDone(m)) { n++; } });
        return n;
    }

    // ---------- events from the game ----------
    function track(what) {
        if (what === 'cross') { state.crossings++; }
        else if (what === 'box') { state.boxes++; }
        save();
        updateBadge();
        if (shop.isOpen() && root.style.display !== 'none') { render(); }
    }

    // ---------- UI ----------
    function toast(text) {
        var t = root.querySelector('.rw-toast');
        if (!t) { return; }
        t.textContent = text;
        t.className = 'rw-toast show';
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function() { t.className = 'rw-toast'; }, 2600);
    }

    function updateBadge() {
        var n = pending();
        if (!badge) { badge = document.getElementById('rewardBadge'); }
        if (badge) { badge.textContent = n ? String(n) : ''; badge.style.display = n ? 'inline-block' : 'none'; }
    }

    function dailyHtml() {
        var done = claimedToday();
        var day = nextDay();
        var html = '<div class="rw-section">Daily reward</div><div class="rw-days">';
        DAILY.forEach(function(p, i) {
            var n = i + 1;
            var cls = 'rw-day';
            if (done && n <= state.streak) { cls += ' got'; }
            else if (!done && n < day) { cls += ' got'; }
            else if (!done && n === day) { cls += ' now'; }
            html += '<div class="' + cls + '"><span>Day ' + n + '</span><b>' +
                    (p === 'character' ? '🎁' : '🪙 ' + p) + '</b></div>';
        });
        html += '</div>';
        html += '<button type="button" class="shop-btn rw-claim" id="rwDaily"' + (done ? ' disabled' : '') + '>' +
                (done ? 'Come back tomorrow!' : 'Claim day ' + day) + '</button>';
        return html;
    }

    function missionsHtml() {
        var html = '<div class="rw-section">Missions</div>';
        MISSIONS.forEach(function(m, i) {
            var v = Math.min(m.value(), m.goal);
            var got = !!state.claimed[m.id];
            var ready = !got && missionDone(m);
            html += '<div class="rw-mission' + (got ? ' got' : '') + '">' +
                    '<div class="rw-info"><div class="rw-name">' + m.name + '</div>' +
                    '<div class="rw-bar"><div style="width:' + Math.round(v / m.goal * 100) + '%"></div></div>' +
                    '<div class="rw-num">' + v + ' / ' + m.goal + '</div></div>' +
                    '<button type="button" class="shop-btn' + (ready ? '' : ' shop-locked') + '" data-m="' + i + '"' +
                    (ready ? '' : ' disabled') + '>' +
                    (got ? 'Done ✔' : '🪙 ' + m.coins) + '</button></div>';
        });
        return html;
    }

    function render() {
        root.innerHTML = '<div class="rw-toast"></div>' + dailyHtml() + missionsHtml();
        var d = root.querySelector('#rwDaily');
        if (d) { d.onclick = claimDaily; }
        Array.prototype.forEach.call(root.querySelectorAll('button[data-m]'), function(b) {
            b.onclick = function() { claimMission(MISSIONS[+b.getAttribute('data-m')]); };
        });
        updateBadge();
    }

    function refresh() { render(); }

    // ---------- start up ----------
    load();
    root = shop.rewardView;
    render();
    shop.onChange(function() { updateBadge(); if (shop.isOpen() && root.style.display !== 'none') { render(); } });
    setInterval(updateBadge, 2000);       // picks up level-ups
    updateBadge();

    return {
        track: track,
        refresh: refresh,
        pending: pending,
        missions: MISSIONS,
        daily: DAILY
    };
})();
