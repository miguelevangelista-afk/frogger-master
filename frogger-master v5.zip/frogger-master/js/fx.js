/* fx.js
 * Efeitos de "perder vida" (dano) no canvas e na tela.
 *
 *  fx.hit(x, y, shielded)  -> chamado quando um inseto acerta o jogador (app.js)
 *      - explosão de pixels no ponto da batida
 *      - texto flutuante "-1" (ou "BLOCK" se o escudo absorveu)
 *      - flash vermelho (azul no escudo) + tremida da tela
 *      - jogador pisca por 1 segundo ao reaparecer
 *
 * Roda mesmo com o menu aberto (fx.update é chamado antes das pausas no engine.js).
 * Depende de: ctx (engine.js), player (app.js).
 */

var fx = (function() {

    var particles = [];
    var floaters = [];
    var flashEl = null;
    var gameEl = null;
    var HURT_TIME = 1.0;

    function el() {
        if (!gameEl) { gameEl = document.getElementById('game'); }
        if (gameEl && !flashEl) {
            flashEl = document.createElement('div');
            flashEl.id = 'fxFlash';
            gameEl.appendChild(flashEl);
        }
        return gameEl;
    }

    // reinicia uma animação CSS adicionando a classe de novo
    function retrigger(node, cls) {
        if (!node) { return; }
        node.classList.remove(cls);
        void node.offsetWidth;
        node.classList.add(cls);
    }

    function burst(x, y, colors, n) {
        for (var i = 0; i < n; i++) {
            var a = Math.random() * Math.PI * 2;
            var sp = 90 + Math.random() * 230;
            particles.push({
                x: x, y: y,
                vx: Math.cos(a) * sp,
                vy: Math.sin(a) * sp - 120,
                size: 4 + Math.floor(Math.random() * 3) * 2,   // 4, 6 ou 8 px (visual "pixel art")
                life: 0.55 + Math.random() * 0.4,
                age: 0,
                color: colors[Math.floor(Math.random() * colors.length)]
            });
        }
    }

    function hit(x, y, shielded) {
        var g = el();
        if (shielded) {
            burst(x, y, ['#9fd8ff', '#ffffff', '#5aa9ff'], 16);
            floaters.push({ x: x, y: y - 40, text: 'BLOCK', color: '#9fd8ff', age: 0, life: 0.9 });
            if (flashEl) { flashEl.className = ''; retrigger(flashEl, 'shield'); }
            return;
        }
        burst(x, y, ['#ff3b3b', '#ff8a3b', '#ffd23b', '#ffffff', '#8a1530'], 28);
        floaters.push({ x: x, y: y - 40, text: '-1 ♥', color: '#ff5470', age: 0, life: 1.1 });
        if (flashEl) { flashEl.className = ''; retrigger(flashEl, 'hurt'); }
        if (g) {
            var cv = g.querySelector('canvas');
            retrigger(cv, 'shake');
        }
        if (window.player) { player.hurtTime = HURT_TIME; }
        if (navigator.vibrate) { try { navigator.vibrate(80); } catch (e) {} }
    }

    function update(dt) {
        if (window.player && player.hurtTime > 0) { player.hurtTime = Math.max(0, player.hurtTime - dt); }
        var i;
        for (i = particles.length - 1; i >= 0; i--) {
            var p = particles[i];
            p.age += dt;
            if (p.age >= p.life) { particles.splice(i, 1); continue; }
            p.vy += 700 * dt;           // gravidade
            p.x += p.vx * dt;
            p.y += p.vy * dt;
        }
        for (i = floaters.length - 1; i >= 0; i--) {
            var f = floaters[i];
            f.age += dt;
            if (f.age >= f.life) { floaters.splice(i, 1); }
        }
    }

    function render() {
        if (!particles.length && !floaters.length) { return; }
        var i;
        ctx.save();
        for (i = 0; i < particles.length; i++) {
            var p = particles[i];
            ctx.globalAlpha = Math.max(0, 1 - p.age / p.life);
            ctx.fillStyle = p.color;
            ctx.fillRect(Math.round(p.x / 2) * 2, Math.round(p.y / 2) * 2, p.size, p.size);
        }
        ctx.font = 'bold 30px "Courier New", monospace';
        ctx.textAlign = 'center';
        ctx.lineWidth = 5;
        ctx.strokeStyle = '#1b1424';
        for (i = 0; i < floaters.length; i++) {
            var f = floaters[i];
            var t = f.age / f.life;
            ctx.globalAlpha = t < 0.7 ? 1 : 1 - (t - 0.7) / 0.3;
            var fy = f.y - t * 60;
            ctx.strokeText(f.text, f.x, fy);
            ctx.fillStyle = f.color;
            ctx.fillText(f.text, f.x, fy);
        }
        ctx.restore();
    }

    return { hit: hit, update: update, render: render, hurtTime: HURT_TIME };
})();
