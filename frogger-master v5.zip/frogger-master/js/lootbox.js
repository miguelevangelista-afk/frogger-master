/* lootbox.js
 * Baús de tesouro aparecem de tempos em tempos nas pistas de pedra.
 * Pise em um para abrir e ganhar uma recompensa aleatória.
 * A raridade define o brilho da gema e a força do prêmio.
 *
 * Depende de: player, allEnemies (app.js), ctx (engine.js), Resources.
 * Para mudar textos, chances ou prêmios, edite RARITIES e REWARDS abaixo.
 */

var lootBox = (function() {

    var COLS = [0, 101, 202, 303, 404];   // colunas possíveis
    var ROWS = [68, 151, 234];            // mesmas linhas de pedra onde andam os insetos

    var SNORLAX_CHANCE = 0.06;            // chance per loot box of the secret Snorlax
    var CHARACTER_CHANCE = 0.08;          // chance per chest of winning a new (unowned) character

    var LIFETIME = 9;                     // segundos que o baú fica na tela
    var POPUP_TIME = 2.2;                 // segundos do aviso de recompensa

    // Chance de cada raridade (os pesos não precisam somar 100)
    var RARITIES = [
        { id: 'common', name: 'COMMON', weight: 60, gem: 'images/Gem Blue.png',   color: '#4aa8ff' },
        { id: 'rare',   name: 'RARE',   weight: 30, gem: 'images/Gem Green.png',  color: '#3fd66f' },
        { id: 'epic',   name: 'EPIC',   weight: 10, gem: 'images/Gem Orange.png', color: '#ffa43a' }
    ];

    // Prêmios de cada raridade (cada um tem o mesmo peso dentro da sua raridade)
    var REWARDS = {
        common: [
            { text: '+1 star!',                  apply: function() { player.win(); } },
            { text: 'Slow-mo for 6 seconds',     apply: function() { player.slowTime = 6; } },
            { text: '+1 LIFE!',                  apply: function() { giveLives(1); } }
        ],
        rare: [
            { text: 'Shield! Blocks 1 hit',      apply: function() { player.shield += 1; } },
            { text: '+2 stars!',                 apply: function() { player.win(); player.win(); } },
            { text: 'Bugs frozen for 5 seconds', apply: function() { player.freezeTime = 5; } },
            { text: '+1 LIFE!',                  apply: function() { giveLives(1); } },
            { text: '+2 LIVES!',                 apply: function() { giveLives(2); } }
        ],
        epic: [
            { text: '+1 SCORE POINT!',           apply: function() { player.score += 1; } },
            { text: 'Double shield! Blocks 2 hits', apply: function() { player.shield += 2; } },
            { text: 'Bugs frozen for 8 seconds', apply: function() { player.freezeTime = 8; } },
            { text: '+2 LIVES!',                 apply: function() { giveLives(2); } },
            { text: 'FULL HEARTS! +3 lives',     apply: function() { giveLives(3); } }
        ]
    };

    // +vidas (respeita o limite de gameEnd.maxLives)
    function giveLives(n) {
        var got = window.gameEnd ? gameEnd.addLife(n) : 0;
        if (got === 0) { player.shield += 1; }     // vidas cheias: ganha um escudo no lugar
        return got;
    }

    function weightedPick(list) {
        var total = 0, i;
        for (i = 0; i < list.length; i++) { total += (list[i].weight || 1); }
        var r = Math.random() * total;
        for (i = 0; i < list.length; i++) {
            r -= (list[i].weight || 1);
            if (r < 0) { return list[i]; }
        }
        return list[list.length - 1];
    }

    // Desenha o baú com formas do canvas (o jogo não tem sprite de baú)
    function drawChest(cx, cy, scale, glow, opening) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.scale(scale, scale);

        if (glow) {
            ctx.fillStyle = 'rgba(255, 220, 90, ' + (0.18 + 0.12 * Math.sin(Date.now() / 150)) + ')';
            ctx.beginPath();
            ctx.arc(0, 0, 44, 0, Math.PI * 2);
            ctx.fill();
        }

        // corpo
        ctx.fillStyle = '#8a4b1f';
        ctx.fillRect(-28, -6, 56, 28);
        // tampa arredondada
        ctx.beginPath();
        var lidLift = opening ? -22 : 0;
        ctx.moveTo(-28, -6 + lidLift);
        ctx.quadraticCurveTo(0, -38 + lidLift, 28, -6 + lidLift);
        ctx.closePath();
        ctx.fillStyle = '#a65d27';
        ctx.fill();
        // faixas de metal
        ctx.fillStyle = '#e0b43a';
        ctx.fillRect(-28, -8 + lidLift, 56, 5);
        ctx.fillRect(-28, 18, 56, 4);
        ctx.fillRect(-20, -22, 5, 16);
        ctx.fillRect(15, -22, 5, 16);
        // fechadura
        ctx.fillStyle = '#ffd966';
        ctx.fillRect(-6, -9, 12, 13);
        ctx.fillStyle = '#5a3210';
        ctx.fillRect(-2, -4, 4, 6);
        // contorno
        ctx.strokeStyle = '#3d210b';
        ctx.lineWidth = 2;
        ctx.strokeRect(-28, -6, 56, 28);

        ctx.restore();
    }

    var box = {
        item: null,          // baú atual { x, y, age }
        spawnTimer: 4,       // primeiro baú aparece em ~4s
        opened: 0,
        popup: null,         // aviso da última recompensa
        particles: [],

        spawn: function() {
            var x, y, tries = 0;
            do {
                x = COLS[Math.floor(Math.random() * COLS.length)];
                y = ROWS[Math.floor(Math.random() * ROWS.length)];
                tries++;
            } while (x === player.x && y === player.y && tries < 10);
            this.item = { x: x, y: y, age: 0 };
        },

        open: function() {
            var rarity = weightedPick(RARITIES);
            var reward = weightedPick(REWARDS[rarity.id].map(function(r) {
                return { weight: 1, reward: r };
            })).reward;

            // secret character: only until you own it
            if (window.shop && !shop.owns('snorlax') && Math.random() < SNORLAX_CHANCE) {
                rarity = RARITIES[RARITIES.length - 1];
                reward = { text: 'SECRET! Snorlax unlocked!', apply: function() { shop.unlockSecret('snorlax'); } };
            }

            // a new character you do not own yet (animated ones included)
            if (window.shop && reward.text.indexOf('SECRET') !== 0 && Math.random() < CHARACTER_CHANCE) {
                var drop = shop.pickDrop();
                if (drop) {
                    rarity = RARITIES[2];
                    reward = { text: 'NEW CHARACTER: ' + drop.name + '!', apply: function() { shop.unlock(drop.id); } };
                }
            }

            reward.apply();
            if (window.rewards) { rewards.track('box'); }
            this.opened++;
            if (window.levelSystem) { levelSystem.addXp(levelSystem.xpPerLootbox); }
            this.popup = { rarity: rarity, text: reward.text, t: POPUP_TIME, age: 0 };

            // confete
            var cx = this.item.x + 50, cy = this.item.y + 105;
            for (var i = 0; i < 26; i++) {
                var a = Math.random() * Math.PI * 2, sp = 60 + Math.random() * 160;
                this.particles.push({
                    x: cx, y: cy,
                    vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 60,
                    life: 0.7 + Math.random() * 0.4,
                    color: i % 3 === 0 ? '#ffd966' : rarity.color
                });
            }

            this.item = null;
            this.spawnTimer = 5 + Math.random() * 4;
        },

        update: function(dt) {
            var i;
            if (this.popup) {
                this.popup.t -= dt;
                this.popup.age += dt;
                if (this.popup.t <= 0) { this.popup = null; }
            }

            for (i = this.particles.length - 1; i >= 0; i--) {
                var p = this.particles[i];
                p.life -= dt;
                p.vy += 400 * dt;
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                if (p.life <= 0) { this.particles.splice(i, 1); }
            }

            if (this.item) {
                this.item.age += dt;
                if (!this.item.opening && this.item.age >= LIFETIME) {
                    // sumiu sem ser aberto
                    this.item = null;
                    this.spawnTimer = 4 + Math.random() * 4;
                } else if (player.x === this.item.x && player.y === this.item.y && !this.item.opening) {
                    this.item.opening = true;
                    this.item.openTimer = 0;
                }
                if (this.item && this.item.opening) {
                    this.item.openTimer += dt;
                    if (this.item.openTimer >= 0.55) { this.open(); }
                }
            } else {
                this.spawnTimer -= dt;
                if (this.spawnTimer <= 0) { this.spawn(); }
            }
        },

        render: function() {
            var i;

            // baú (pisca nos últimos 2.5s antes de sumir)
            if (this.item) {
                var left = LIFETIME - this.item.age;
                var visible = left > 2.5 || Math.floor(left * 6) % 2 === 0;
                if (visible) {
                    var bob = Math.sin(this.item.age * 4) * 3;
                    var op = this.item.opening ? this.item.openTimer : 0;
                    var shake = this.item.opening ? Math.sin(op * 70) * 2 : 0;
                    drawChest(this.item.x + 50 + shake, this.item.y + 105 + bob, 1 + op * 0.35, true, this.item.opening);
                    ctx.fillStyle = '#fff';
                    ctx.strokeStyle = '#3d210b';
                    ctx.lineWidth = 3;
                    ctx.font = 'bold 20px Arial';
                    ctx.textAlign = 'center';
                    ctx.strokeText('?', this.item.x + 50, this.item.y + 108 + bob);
                    ctx.fillText('?', this.item.x + 50, this.item.y + 108 + bob);
                }
            }

            // confete
            for (i = 0; i < this.particles.length; i++) {
                var p = this.particles[i];
                ctx.globalAlpha = Math.max(0, Math.min(1, p.life * 2));
                ctx.fillStyle = p.color;
                ctx.fillRect(p.x - 3, p.y - 3, 6, 6);
            }
            ctx.globalAlpha = 1;

            // aviso da recompensa
            if (this.popup) {
                var pp = this.popup;
                var fade = Math.min(1, pp.t / 0.4);
                var gem = Resources.get(pp.rarity.gem);

                ctx.save();
                ctx.globalAlpha = fade;
                var popScale = 0.78 + 0.22 * Math.min(1, pp.age * 5);
                ctx.translate(252.5, 305);
                ctx.scale(popScale, popScale);
                ctx.translate(-252.5, -305);
                ctx.fillStyle = 'rgba(20, 20, 30, 0.92)';
                ctx.fillRect(52, 250, 401, 110);
                ctx.strokeStyle = pp.rarity.color;
                ctx.lineWidth = 4;
                ctx.strokeRect(52, 250, 401, 110);

                if (gem) { ctx.drawImage(gem, 62, 262, 55, 94); }

                ctx.textAlign = 'center';
                ctx.fillStyle = pp.rarity.color;
                ctx.font = 'bold 26px Arial';
                ctx.fillText(pp.rarity.name + ' LOOT BOX!', 290, 292);
                ctx.fillStyle = '#fff';
                ctx.font = 'bold 18px Arial';
                ctx.fillText(pp.text, 290, 330);
                ctx.restore();
            }

            ctx.textAlign = 'start';
        }
    };

    return box;
})();
