/* gameover.js
 * Lives + Game Over / Victory screens.
 *
 * - You start with START_LIVES lives. Every bug hit costs one life
 *   (a shield still absorbs the hit first, see app.js).
 * - 0 lives          -> DEFEAT screen (Game Over)
 * - score >= WIN_SCORE -> VICTORY screen
 *
 * Change the two numbers below to tune the game.
 * Depends on: player, allEnemies (app.js), levelSystem (level.js), shop (shop.js).
 */

var gameEnd = (function() {

    var START_LIVES = 3;
    var MAX_LIVES = 6;      // loot boxes can raise your lives up to this number
    var WIN_SCORE = 5;      // score needed to win (1 score = 5 crossings)

    var lives = START_LIVES;
    var state = 'playing';  // 'playing' | 'won' | 'lost'
    var overlay, ribbon, stats, livesEl, curtain, partsEl, playBtn;
    var bar = {};            // pedaços da barra de vida (medalhão, preenchimento, "fantasma")
    var shownLives = -1;     // vida mostrada na barra (para saber se perdeu ou ganhou)
    var readyAt = 0;         // só deixa reiniciar depois que a animação de Game Over termina
    var countTimer = null;

    // coração em pixel art (9 x 8) desenhado em SVG, sem imagem externa
    var HEART = ['.XX...XX.', 'XHXX.XXXX', 'XXXXXXXXX', 'XXXXXXXXX', '.XXXXXXX.', '..XXXXX..', '...XXX...', '....X....'];
    function heartSvg() {
        var r = '';
        for (var y = 0; y < HEART.length; y++) {
            for (var x = 0; x < HEART[y].length; x++) {
                var c = HEART[y][x];
                if (c === '.') { continue; }
                r += '<rect x="' + x + '" y="' + y + '" width="1" height="1" fill="' + (c === 'H' ? '#ff9db0' : '#e0405e') + '"/>';
            }
        }
        return '<svg viewBox="-0.5 -0.5 10 9" shape-rendering="crispEdges" aria-hidden="true">' +
               r + '</svg>';
    }

    // Barra de vida: medalhão com coração + barra que esvazia (estilo pixel art)
    function buildBar() {
        livesEl.innerHTML =
            '<div class="hb" role="img">' +
              '<div class="hb-medal">' + heartSvg() + '</div>' +
              '<div class="hb-track"><div class="hb-inner">' +
                '<div class="hb-ghost"></div><div class="hb-fill"></div><div class="hb-ticks"></div>' +
              '</div></div>' +
              '<span class="hb-num"></span>' +
            '</div>';
        bar.root = livesEl.firstChild;
        bar.fill = livesEl.querySelector('.hb-fill');
        bar.ghost = livesEl.querySelector('.hb-ghost');
        bar.ticks = livesEl.querySelector('.hb-ticks');
        bar.num = livesEl.querySelector('.hb-num');
        var t = '';
        for (var i = 1; i < MAX_LIVES; i++) { t += '<i style="left:' + (i * 100 / MAX_LIVES) + '%"></i>'; }
        bar.ticks.innerHTML = t;
    }

    function play(node, cls) {          // reinicia uma animação CSS
        node.classList.remove(cls);
        void node.offsetWidth;
        node.classList.add(cls);
    }

    function renderLives() {
        if (!livesEl) { return; }
        if (!bar.root) { buildBar(); }
        var pct = (lives / MAX_LIVES * 100) + '%';
        var lost = shownLives >= 0 && lives < shownLives;
        var gained = shownLives >= 0 && lives > shownLives;

        if (lost) {
            // a barra cai de uma vez; o "fantasma" amarelo escorrega depois (efeito de dano)
            bar.ghost.style.transition = 'width .55s steps(8) .4s';
            bar.fill.style.width = pct;
            bar.ghost.style.width = pct;
            play(bar.root, 'hit');
        } else if (gained) {
            bar.ghost.style.transition = 'none';
            bar.ghost.style.width = pct;
            bar.fill.style.width = pct;
            play(bar.root, 'heal');
        } else {
            bar.ghost.style.transition = 'none';
            bar.fill.style.width = pct;
            bar.ghost.style.width = pct;
        }
        bar.root.classList.toggle('low', lives === 1);
        bar.root.classList.toggle('dead', lives === 0);
        bar.root.setAttribute('aria-label', 'Lives ' + lives + ' of ' + MAX_LIVES);
        bar.num.textContent = 'x' + lives;
        shownLives = lives;
    }

    // ----- animação de Game Over / Vitória -----
    function clearParts() {
        partsEl.innerHTML = '';
        if (countTimer) { clearInterval(countTimer); countTimer = null; }
    }

    function spawnParts(kind) {
        clearParts();
        var n = kind === 'won' ? 36 : 22, html = '';
        var colors = kind === 'won' ? ['#ffd23b', '#5cb811', '#4aa8ff', '#ff5470', '#ffffff'] : ['#ff5a2a', '#ff9a2a', '#ffd23b', '#8a1530'];
        for (var i = 0; i < n; i++) {
            var sz = 4 + Math.floor(Math.random() * 3) * 2;
            html += '<b style="left:' + (Math.random() * 100).toFixed(1) + '%;width:' + sz + 'px;height:' + sz + 'px;' +
                    'background:' + colors[i % colors.length] + ';' +
                    'animation-delay:' + (0.6 + Math.random() * 2.4).toFixed(2) + 's;' +
                    'animation-duration:' + (2 + Math.random() * 2).toFixed(2) + 's"></b>';
        }
        partsEl.innerHTML = html;
    }

    function countUp(target) {          // pontuação sobe de 0 até o valor final
        var n = 0;
        var node = document.getElementById('endScore');
        if (!node) { return; }
        node.textContent = '0';
        if (target <= 0) { return; }
        countTimer = setInterval(function() {
            n++;
            node.textContent = String(n);
            if (n >= target) { clearInterval(countTimer); countTimer = null; }
        }, 220);
    }

    function show(kind) {
        state = kind;
        ribbon.src = kind === 'won' ? 'images/ui-victory.png' : 'images/ui-defeat.png';
        ribbon.alt = kind === 'won' ? 'Victory' : 'Defeat';
        var lvl = window.levelSystem ? levelSystem.level : 1;
        stats.innerHTML = 'Score <span id="endScore">' + player.score + '</span> &nbsp;|&nbsp; Level ' + lvl +
            (kind === 'lost' ? '<br><small>Your level was reset to 1</small>' : '');
        var gm = document.getElementById('game');
        if (gm) { gm.classList.toggle('dying', kind === 'lost'); }
        overlay.className = kind;
        overlay.style.display = 'flex';
        // reinicia as animações CSS do overlay
        overlay.classList.remove('play');
        void overlay.offsetWidth;
        overlay.classList.add('play');
        spawnParts(kind);
        countUp(player.score);
        readyAt = Date.now() + (kind === 'lost' ? 1700 : 900);
        if (gm && gm.scrollIntoView) { gm.scrollIntoView({ block: 'start', behavior: 'smooth' }); }
        if (playBtn) { playBtn.focus(); }
    }

    function loseLife() {
        if (state !== 'playing') { return; }
        lives = Math.max(0, lives - 1);
        renderLives();
        if (lives === 0) {
            show('lost');                       // shows the level you reached...
            if (window.levelSystem) { levelSystem.reset(); }   // ...then sends you back to level 1
        }
    }

    // Loot boxes: gain lives (never above MAX_LIVES). Returns how many were really added.
    function addLife(n) {
        if (state !== 'playing') { return 0; }
        var before = lives;
        lives = Math.min(MAX_LIVES, lives + (n || 1));
        renderLives();
        return lives - before;
    }

    // Called every frame from Player.update (also catches loot box score points)
    function check() {
        if (state === 'playing' && player.score >= WIN_SCORE) { show('won'); }
    }

    function restart() {
        if (state !== 'playing' && Date.now() < readyAt) { return; }   // espera a animação terminar
        lives = START_LIVES;
        shownLives = -1;
        clearParts();
        var gm = document.getElementById('game');
        if (gm) { gm.classList.remove('dying'); }
        if (window.player) { player.hurtTime = 0; }
        state = 'playing';
        player.score = 0;
        player.won.length = 0;
        player.shield = 0;
        player.slowTime = 0;
        player.freezeTime = 0;
        player.reset();
        allEnemies.forEach(function(e) { e.respawn(true); });
        overlay.style.display = 'none';
        overlay.classList.remove('play');
        renderLives();
    }

    function build() {
        var game = document.getElementById('game');
        livesEl = document.getElementById('lives');

        overlay = document.createElement('div');
        overlay.id = 'endScreen';
        overlay.style.display = 'none';
        overlay.innerHTML =
            '<div id="endCurtain"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>' +
            '<div id="endParts"></div>' +
            '<img id="endRibbon" alt="">' +
            '<div id="endStats"></div>' +
            '<button type="button" id="playAgain">Play Again</button>';
        game.appendChild(overlay);
        curtain = document.getElementById('endCurtain');
        partsEl = document.getElementById('endParts');
        playBtn = document.getElementById('playAgain');

        ribbon = document.getElementById('endRibbon');
        stats = document.getElementById('endStats');
        document.getElementById('playAgain').addEventListener('click', restart);

        // Enter / Space also restarts (keyboard players)
        document.addEventListener('keydown', function(e) {
            if (state !== 'playing' && (e.keyCode === 13 || e.keyCode === 32)) {
                e.preventDefault();
                restart();
            }
        });
        renderLives();
    }

    build();

    return {
        loseLife: loseLife,
        addLife: addLife,
        lives: function() { return lives; },
        maxLives: MAX_LIVES,
        check: check,
        restart: restart,
        isOver: function() { return state !== 'playing'; }
    };
})();
