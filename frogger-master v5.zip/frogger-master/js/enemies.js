/* enemies.js
 * Enemy types and the rules for which ones can appear at each level.
 *
 * To add a new type: add an entry to ENEMY_TYPES and (if it needs special
 * behaviour) handle its id in Enemy.prototype.update in app.js.
 *
 *   minLevel : first level where this enemy can appear
 *   weight   : how common it is compared with the other unlocked types
 *   speed    : speed multiplier
 *   tint     : colour overlay on the bug sprite (null = original colours)
 *   reverse  : true = walks from right to left
 *   sprite   : own image (instead of the tinted bug)
 *   maps     : (optional) only appears in these maps (ids from maps.js); no field = every map
 * Each map can re-skin a type (other name/colour): see `skins` in maps.js.
 */

var ENEMY_TYPES = [
    { id: 'bug',      name: 'Bug',       minLevel: 1,  weight: 50, speed: 1,    tint: null },
    { id: 'speeder',  name: 'Speeder',   minLevel: 3,  weight: 25, speed: 1.5,  tint: '#2f7bff' },
    { id: 'zigzag',   name: 'Zigzag',    minLevel: 5,  weight: 25, speed: 0.85, tint: '#b04bff' },
    { id: 'charger',  name: 'Charger',   minLevel: 8,  weight: 25, speed: 0.6,  tint: '#ffd21f' },
    { id: 'reverse',  name: 'Backtrack', minLevel: 10, weight: 25, speed: 1.1,  tint: '#35d6c4', reverse: true },
    // new: appears after level 10 (flies a bit faster than the bugs)
    { id: 'dragon',   name: 'Dragon',    minLevel: 11, weight: 25, speed: 1.25, tint: null, sprite: 'images/enemy-dragon.png', maps: ['desert', 'volcano'] },
    // new: appears from level 70 (slow, but hunts the lane you are in)
    { id: 'reaper',   name: 'Reaper',    minLevel: 70, weight: 25, speed: 0.8,  tint: null, sprite: 'images/enemy-reaper.png' }
];

function unlockedEnemyTypes(level) {
    var map = window.mapSystem ? mapSystem.forLevel(level) : null;
    return ENEMY_TYPES.filter(function(t) {
        return t.minLevel <= level && (!t.maps || !map || t.maps.indexOf(map.id) !== -1);
    });
}

// Display name / tint of a type, with the current map's skin applied
function enemyName(type, level) {
    var sk = window.mapSystem ? mapSystem.skin(mapSystem.forLevel(level), type.id) : null;
    return sk ? sk.name : type.name;
}

function pickEnemyType(level) {
    var list = unlockedEnemyTypes(level), total = 0, i;
    for (i = 0; i < list.length; i++) { total += list[i].weight; }
    var r = Math.random() * total;
    for (i = 0; i < list.length; i++) {
        r -= list[i].weight;
        if (r < 0) { return list[i]; }
    }
    return list[0];
}

// Coloured copies of the bug sprite (made once, then reused)
var tintedSprites = {};
function getEnemySprite(type) {
    if (type.sprite) { return Resources.get(type.sprite); }
    var base = Resources.get('images/enemy-bug.png');
    var lvl = window.levelSystem ? levelSystem.level : 1;
    var sk = window.mapSystem ? mapSystem.skin(mapSystem.forLevel(lvl), type.id) : null;
    var tint = sk ? sk.tint : type.tint;
    var key = type.id + '|' + (tint || '');
    if (!tint || !base) { return base; }
    if (!tintedSprites[key]) {
        var c = document.createElement('canvas');
        c.width = base.width;
        c.height = base.height;
        var g = c.getContext('2d');
        g.drawImage(base, 0, 0);
        g.globalCompositeOperation = 'source-atop';
        g.globalAlpha = 0.55;
        g.fillStyle = tint;
        g.fillRect(0, 0, c.width, c.height);
        tintedSprites[key] = c;
    }
    return tintedSprites[key];
}
