/* boxes.js
 * Loot boxes: pay coins to open a box, a roller slides past a strip of prizes
 * and lands on a random coin reward (inspired by the CS:GO-style box roller).
 *
 * - Coins come from playing (see shop.js). Nothing here uses real money.
 * - Each prize has a rarity: F Garbage, D Heavily Worn, C A few scratches,
 *   B Good Condition, A Fresh Out of the Box (rarer = bigger prize).
 * - The cost is paid when the roll starts and the prize is paid when it ends.
 *   If the page is closed in the middle, the prize is paid on the next visit.
 *
 * To add a box, add one line to BOXES below. To tune the odds, edit TIERS.
 * Depends on: shop (shop.js).
 */

var boxes = (function() {

    var KEY = 'frogger-boxes-v1';
    var ROLL_TIME = 5000;              // ms the roller spins
    var STRIP_LEN = 56;                // tiles in the strip
    var WIN_INDEX = 46;                // tile that is the real prize
    var TILE_W = 78, TILE_GAP = 4;     // px

    // low -> high rarity. weight = chance, lo/hi = prize as a multiple of the box price
    var TIERS = [
        { code: 'F', name: 'Garbage',             icon: 'images/Rock.png',       weight: 42,  lo: 0.2, hi: 0.6 },
        { code: 'D', name: 'Heavily Worn',        icon: 'images/Key.png',        weight: 30,  lo: 0.6, hi: 1.0 },
        { code: 'C', name: 'A few scratches',     icon: 'images/Gem Green.png',  weight: 17,  lo: 1.0, hi: 1.6 },
        { code: 'B', name: 'Good Condition',      icon: 'images/Gem Blue.png',   weight: 8.5, lo: 1.6, hi: 3.0 },
        { code: 'A', name: 'Fresh Out of the Box', icon: 'images/Gem Orange.png', weight: 2.5, lo: 3.0, hi: null }  // hi = box.max
    ];

    // price = coins to open, max = best possible prize as a multiple of the price
    // (on average a box pays back a little less than it costs; the big ones pay back more)
    var BOXES = [
        { id: 'wood',  name: 'Wooden Box', emoji: '\uD83D\uDCE6', price: 20,  max: 5 },
        { id: 'iron',  name: 'Iron Box',   emoji: '\uD83E\uDDF0', price: 60,  max: 7 },
        { id: 'gold',  name: 'Gold Box',   emoji: '\uD83D\uDCB0', price: 150, max: 9 },
        { id: 'royal', name: 'Royal Box',  emoji: '\uD83D\uDC51', price: 400, max: 10 }
    ];

    // Chance that a box ALSO gives you a new character you do not own yet.
    // It depends on the prize rarity and on the box (bigger boxes = better odds).
    var CHAR_CHANCE = { F: 0, D: 0, C: 0.04, B: 0.12, A: 0.35 };
    var BOX_LUCK = { wood: 0.6, iron: 1, gold: 1.5, royal: 2 };
    // Extra lives a box can ALSO give (needs to be playing; capped by gameEnd.maxLives)
    var LIFE_CHANCE = { F: 0, D: 0.05, C: 0.15, B: 0.35, A: 0.7 };
    var LIFE_AMOUNT = { F: 1, D: 1, C: 1, B: 1, A: 2 };
    var PITY = 12;                     // after this many boxes without a character, the next box gives one

    var state = { opened: 0, best: 0, pending: 0, muted: false, dry: 0, pendingChar: '' };
    var rolling = false, timer = null, raf = null, current = null, lastTick = -1;
    var audioCtx = null;
    var el = {};

    // ---------- saving ----------
    function load() {
        try {
            var s = JSON.parse(window.localStorage.getItem(KEY));
            if (s) {
                state.opened = s.opened | 0;
                state.best = s.best | 0;
                state.pending = s.pending | 0;
                state.muted = !!s.muted;
                state.dry = s.dry | 0;
                state.pendingChar = typeof s.pendingChar === 'string' ? s.pendingChar : '';
            }
        } catch (e) {}
    }
    function save() {
        try { window.localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
    }

    // ---------- odds ----------
    function pickTier() {
        var total = 0, i;
        for (i = 0; i < TIERS.length; i++) { total += TIERS[i].weight; }
        var r = Math.random() * total;
        for (i = 0; i < TIERS.length; i++) {
            r -= TIERS[i].weight;
            if (r < 0) { return TIERS[i]; }
        }
        return TIERS[0];
    }

    function tierHi(box, tier) { return tier.hi === null ? box.max : tier.hi; }

    function prizeFor(box, tier) {
        var m = tier.lo + Math.random() * (tierHi(box, tier) - tier.lo);
        return Math.max(1, Math.round(box.price * m));
    }

    // decide (without unlocking yet) whether this box also drops a character
    function rollCharacter(box, tier) {
        if (!shop.pickDrop()) { return null; }       // you already own everything
        var chance = Math.min(0.9, (CHAR_CHANCE[tier.code] || 0) * (BOX_LUCK[box.id] || 1));
        if (state.dry + 1 >= PITY || Math.random() < chance) { return shop.pickDrop(); }
        return null;
    }

    function minPrize(box) { return Math.max(1, Math.round(box.price * TIERS[0].lo)); }
    function maxPrize(box) { return Math.round(box.price * box.max); }

    // ---------- sound (small chiptune beeps, can be muted) ----------
    function beep(freq, dur, vol, type) {
        if (state.muted) { return; }
        try {
            if (!audioCtx) { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
            if (audioCtx.state === 'suspended') { audioCtx.resume(); }
            var o = audioCtx.createOscillator(), g = audioCtx.createGain();
            o.type = type || 'square';
            o.frequency.value = freq;
            g.gain.value = vol || 0.04;
            g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
            o.connect(g);
            g.connect(audioCtx.destination);
            o.start();
            o.stop(audioCtx.currentTime + dur);
        } catch (e) {}
    }
    function winSound(tier) {
        var base = { F: 220, D: 262, C: 330, B: 392, A: 523 }[tier.code] || 262;
        [0, 1, 2].forEach(function(i) {
            setTimeout(function() { beep(base * Math.pow(1.25, i), 0.18, 0.06, 'triangle'); }, i * 110);
        });
    }

    // ---------- UI ----------
    function tileHtml(tier, value) {
        return '<div class="box-tile t-' + tier.code + '"><img src="' + tier.icon + '" alt=""><span>+' + value + '</span></div>';
    }

    function build() {
        var root = shop.boxView;
        root.innerHTML =
            '<div class="box-roller"><div class="box-strip"></div><div class="box-marker"></div></div>' +
            '<div class="box-tools">' +
                '<button type="button" class="shop-btn" id="boxSkip" disabled>Skip</button>' +
                '<button type="button" class="shop-btn" id="boxSound"></button>' +
            '</div>' +
            '<div class="box-result"></div>' +
            '<div class="box-list"></div>' +
            '<div class="box-foot"></div>';
        el.roller = root.querySelector('.box-roller');
        el.strip = root.querySelector('.box-strip');
        el.result = root.querySelector('.box-result');
        el.list = root.querySelector('.box-list');
        el.foot = root.querySelector('.box-foot');
        el.skip = root.querySelector('#boxSkip');
        el.sound = root.querySelector('#boxSound');
        el.skip.onclick = skip;
        el.sound.onclick = function() { state.muted = !state.muted; save(); renderTools(); };
        showIdleStrip();
        renderTools();
    }

    // a decorative strip before the first roll
    function showIdleStrip() {
        var html = '';
        for (var i = 0; i < 14; i++) {
            var t = pickTier();
            html += tileHtml(t, prizeFor(BOXES[1], t));
        }
        el.strip.style.transition = 'none';
        el.strip.style.transform = 'translateX(0)';
        el.strip.innerHTML = html;
    }

    function renderTools() {
        el.sound.textContent = state.muted ? 'Sound: off' : 'Sound: on';
        el.skip.disabled = !rolling;
    }

    function renderList() {
        el.list.innerHTML = '';
        var coins = shop.coins();
        BOXES.forEach(function(box) {
            var card = document.createElement('div');
            card.className = 'shop-card box-card';
            card.innerHTML =
                '<div class="box-emoji">' + box.emoji + '</div>' +
                '<div class="shop-name">' + box.name + '</div>' +
                '<div class="box-range">Prizes ' + minPrize(box) + ' - ' + maxPrize(box) + '</div>';
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'shop-btn' + (coins < box.price ? ' shop-locked' : '');
            btn.textContent = 'Open \uD83E\uDE99 ' + box.price;
            btn.disabled = rolling;
            btn.onclick = function() { openBox(box); };
            card.appendChild(btn);
            el.list.appendChild(card);
        });
    }

    function renderFoot() {
        el.foot.textContent = 'Boxes opened: ' + state.opened + '  |  Best prize: ' + state.best + ' coins' +
            (shop.pickDrop() ? '  |  New character guaranteed within ' + Math.max(0, PITY - state.dry) + ' boxes' : '');
    }

    function say(html, cls) {
        el.result.className = 'box-result' + (cls ? ' ' + cls : '');
        el.result.innerHTML = html;
    }

    // ---------- opening a box ----------
    function openBox(box) {
        if (rolling) { return; }
        if (shop.coins() < box.price) { say('Not enough coins! Cross the road to earn more.', 'bad'); return; }

        var tier = pickTier();
        var prize = prizeFor(box, tier);
        var drop = rollCharacter(box, tier);
        var lifeWon = Math.random() < (LIFE_CHANCE[tier.code] || 0) * (BOX_LUCK[box.id] || 1) ? (LIFE_AMOUNT[tier.code] || 1) : 0;
        if (!shop.spend(box.price)) { return; }
        rolling = true;
        current = { box: box, tier: tier, prize: prize, drop: drop, lives: lifeWon };
        state.pending = prize;          // safe even if the page closes now
        state.pendingChar = drop ? drop.id : '';
        save();

        // build the strip: random decoys, with the real prize at WIN_INDEX
        var html = '', i;
        for (i = 0; i < STRIP_LEN; i++) {
            if (i === WIN_INDEX) { html += tileHtml(tier, prize); continue; }
            var t = pickTier();
            html += tileHtml(t, prizeFor(box, t));
        }
        el.strip.style.transition = 'none';
        el.strip.style.transform = 'translateX(0)';
        el.strip.innerHTML = html;
        say('Rolling ' + box.name + '...');
        renderList();
        renderTools();

        // land somewhere inside the winning tile (not always dead centre)
        var step = TILE_W + TILE_GAP;
        var jitter = (Math.random() - 0.5) * TILE_W * 0.6;
        var x = -(WIN_INDEX * step + TILE_W / 2 + jitter) + el.roller.clientWidth / 2;
        current.finalX = x;
        void el.strip.offsetWidth;      // restart the transition
        el.strip.style.transition = 'transform ' + ROLL_TIME + 'ms cubic-bezier(0.12, 0.6, 0.1, 1)';
        el.strip.style.transform = 'translateX(' + x + 'px)';

        lastTick = -1;
        raf = requestAnimationFrame(tickLoop);
        timer = setTimeout(finish, ROLL_TIME + 150);
    }

    // a click sound every time a tile passes under the marker
    function tickLoop() {
        if (!rolling) { return; }
        try {
            var tx = new DOMMatrix(getComputedStyle(el.strip).transform).m41;
            var idx = Math.floor((el.roller.clientWidth / 2 - tx) / (TILE_W + TILE_GAP));
            if (idx !== lastTick) { lastTick = idx; beep(700 + (idx % 3) * 40, 0.04, 0.03); }
        } catch (e) {}
        raf = requestAnimationFrame(tickLoop);
    }

    function skip() {
        if (!rolling) { return; }
        el.strip.style.transition = 'none';
        el.strip.style.transform = 'translateX(' + current.finalX + 'px)';
        finish();
    }

    function finish() {
        if (!rolling) { return; }
        clearTimeout(timer);
        cancelAnimationFrame(raf);
        rolling = false;
        var r = current;
        state.pending = 0;
        state.pendingChar = '';
        state.opened++;
        state.best = Math.max(state.best, r.prize);
        state.dry = r.drop ? 0 : state.dry + 1;
        save();
        shop.addCoins(r.prize);        // also refreshes the balance everywhere
        if (r.drop) { shop.unlock(r.drop.id); }
        if (window.rewards) { rewards.track('box'); }

        var tile = el.strip.children[WIN_INDEX];
        if (tile) { tile.className += ' win'; }
        var net = r.prize - r.box.price;
        say('<b>+' + r.prize + ' coins</b> &middot; ' + r.tier.name + ' (' + r.tier.code + ')<br>' +
            '<span class="' + (net >= 0 ? 'good' : 'bad') + '">' + (net >= 0 ? 'Profit +' : 'Loss ') + net + '</span>',
            'rar-' + r.tier.code);
        if (r.drop) { showDrop(r.drop); }
        if (r.lives > 0 && window.gameEnd) {
            var got = gameEnd.addLife(r.lives);
            el.result.innerHTML += '<br><b style="color:#ff6b81">' + (got > 0
                ? '\u2764 +' + got + (got > 1 ? ' LIVES!' : ' LIFE!')
                : (gameEnd.isOver() ? '\u2764 Life saved only while playing' : '\u2764 Hearts already full')) + '</b>';
        }
        winSound(r.tier);
        renderList();
        renderTools();
        renderFoot();
    }

    // celebration card for a character won from a box (it dances!)
    function showDrop(c) {
        var rar = shop.rarities[c.rarity] || {};
        var wrap = document.createElement('div');
        wrap.className = 'box-drop';
        wrap.style.borderColor = rar.color || '#fff';
        wrap.appendChild(shop.makeThumb(c));
        var txt = document.createElement('div');
        txt.innerHTML = '<b>NEW CHARACTER!</b><br>' + c.name + '<br><span style="color:' + (rar.color || '#fff') + '">' + (rar.name || '') + '</span>';
        wrap.appendChild(txt);
        el.result.appendChild(wrap);
        [0, 1, 2, 3].forEach(function(i) {
            setTimeout(function() { beep(523 * Math.pow(1.26, i), 0.16, 0.06, 'square'); }, 500 + i * 100);
        });
    }

    // called by shop.js every time the Loot Boxes tab is shown
    function refresh() {
        renderList();
        renderTools();
        renderFoot();
    }

    // ---------- start up ----------
    load();
    build();
    shop.onCoins(function() { if (!rolling) { renderList(); } });
    if (state.pending > 0) {        // page was closed while a box was rolling
        var owed = state.pending;
        state.pending = 0;
        save();
        shop.addCoins(owed);
        say('Your unclaimed prize arrived: <b>+' + owed + ' coins</b>', 'good');
    }
    if (state.pendingChar) {         // a character was won right before the page closed
        shop.unlock(state.pendingChar);
        state.pendingChar = '';
        save();
    }
    refresh();

    return {
        boxes: BOXES,
        tiers: TIERS,
        open: openBox,
        pity: PITY,
        dry: function() { return state.dry; },
        refresh: refresh,
        // average payout / price for a box (used for tuning)
        expectedReturn: function(box) {
            var total = 0, ev = 0;
            TIERS.forEach(function(t) { total += t.weight; });
            TIERS.forEach(function(t) { ev += t.weight / total * (t.lo + tierHi(box, t)) / 2; });
            return ev;
        }
    };
})();
