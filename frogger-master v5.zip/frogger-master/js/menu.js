/* menu.js
 * Main menu: opens when the game starts and any time you press the "Menu"
 * button (or Esc). The game is paused while it is open.
 *
 * To add a button: add a line to ITEMS below ([label, function]).
 * Depends on: shop, bossFight, profile, saveGame/continueGame/toggleMusic (index.html).
 * Load it AFTER profile.js and BEFORE rewards.js (it holds the Rewards badge).
 */

var gameMenu = (function() {

    var openFlag = false;
    var overlay, nameEl;

    // [label, action, optional id]. Actions run after the menu closes.
    var ITEMS = [
        ['▶ Play',            function() {}, 'mnPlay'],
        ['⟳ Continue saved',  function() { continueGame(); }],
        ['🛒 Shop / Characters', function() { shop.open('characters'); }],
        ['🎁 Loot Boxes',     function() { shop.open('boxes'); }],
        ['⭐ Rewards',        function() { shop.open('rewards'); }, 'openRewards'],
        ['⚔ Boss Fight',     function() { bossFight.fightNext(); }, 'openBoss'],
        ['Practice: Ogre',    function() { bossFight.start('ogre', true); }],
        ['Practice: Golem',   function() { bossFight.start('golem', true); }],
        ['👤 Profile',        function() { profile.open(); }],
        ['💾 Save',           function() { saveGame(); }],
        ['🎵 Music',          function() { toggleMusic(); }]
    ];

    function build() {
        var game = document.getElementById('game');
        overlay = document.createElement('div');
        overlay.id = 'gameMenu';
        overlay.style.display = 'none';

        var title = document.createElement('div');
        title.className = 'mn-title';
        title.textContent = '🐸 Frogger';
        overlay.appendChild(title);

        nameEl = document.createElement('div');
        nameEl.className = 'mn-player';
        overlay.appendChild(nameEl);

        var list = document.createElement('div');
        list.className = 'mn-list';
        ITEMS.forEach(function(it, i) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'mn-btn' + (i === 0 ? ' mn-primary' : '');
            if (it[2] && it[2] !== 'mnPlay') { b.id = it[2]; }
            b.appendChild(document.createTextNode(it[0]));
            if (it[2] === 'openRewards') {
                var badge = document.createElement('span');
                badge.id = 'rewardBadge';
                badge.className = 'badge';
                badge.style.display = 'none';
                b.appendChild(badge);
            }
            b.onclick = function() { close(); it[1](); };
            list.appendChild(b);
        });
        overlay.appendChild(list);

        var hint = document.createElement('div');
        hint.className = 'mn-hint';
        hint.textContent = 'Move: arrow keys or W A S D · Menu: Esc';
        overlay.appendChild(hint);

        game.appendChild(overlay);
    }

    var closeTimer = null;
    var CLOSE_MS = 340;      // duração da animação de fechar (igual ao CSS .mn-out)

    function open() {
        if (window.shop && shop.isOpen()) { shop.close(); }
        if (window.profile && profile.isOpen()) { profile.close(); }
        if (window.bossFight && bossFight.isOpen()) { return; }
        if (nameEl && window.profile) { nameEl.textContent = '👤 ' + profile.name(); }
        if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
        overlay.classList.remove('mn-out');
        overlay.style.display = 'flex';
        overlay.classList.remove('mn-in');
        void overlay.offsetWidth;            // reinicia a animação de abrir
        overlay.classList.add('mn-in');
        openFlag = true;
    }

    // O jogo volta a rodar na hora; o painel some com uma animação (porta de pixels fechando)
    function close() {
        if (!openFlag) { return; }
        openFlag = false;
        overlay.classList.remove('mn-in');
        overlay.classList.add('mn-out');
        if (closeTimer) { clearTimeout(closeTimer); }
        closeTimer = setTimeout(function() {
            closeTimer = null;
            overlay.classList.remove('mn-out');
            overlay.style.display = 'none';
        }, CLOSE_MS);
    }

    function toggle() { if (openFlag) { close(); } else { open(); } }

    build();
    document.addEventListener('keydown', function(e) {
        if (e.keyCode !== 27) { return; }
        if ((window.shop && shop.isOpen()) || (window.profile && profile.isOpen())) { return; }
        toggle();
    });
    open();   // start screen

    return { open: open, close: close, toggle: toggle, isOpen: function() { return openFlag; } };
})();
