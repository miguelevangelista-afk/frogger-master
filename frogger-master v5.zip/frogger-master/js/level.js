/* level.js
 * Experience + levels. Every level adds more enemies, and new enemy
 * types unlock as you go (see enemies.js).
 *
 * Enemies per level: level 1 -> 2, level 11 -> 6, level 21 -> 10 (max 12). The Reaper only appears from level 70.
 * Level-up plays a +1UP animation (arrows, rings, sparks).
 * Change the numbers below to tune the difficulty.
 *
 * Depends on: player, allEnemies, Enemy (app.js), ctx (engine.js), shop (shop.js).
 */

var levelSystem = (function() {

    var XP_PER_CROSSING = 20;      // XP for reaching the water
    var XP_PER_LOOTBOX = 10;       // XP for opening a loot box
    var LEVEL_UP_COINS = 25;       // coin bonus on every level-up
    var MAX_ENEMIES = 12;          // only 3 lanes: more than this is impossible to dodge
    var POPUP_TIME = 2.6;
    var FX_TIME = 2.2;             // length of the level-up animation (seconds)
    var KEY = 'frogger-level-v1';

    var state = { level: 1, xp: 0 };
    var popup = null;
    var fx = null;          // level-up animation
    var sparks = [];

    // XP needed to go from this level to the next (level 1 -> 24, level 10 -> 60, level 20 -> 100).
    // About 18 crossings reach level 10 and ~57 reach level 20, so new enemies show up in time.
    function xpNeeded(level) { return 20 + 4 * level; }

    // Level 1 -> 2 enemies, level 11 -> 6, level 21 -> 10, capped at MAX_ENEMIES
    function enemiesForLevel(level) {
        return Math.min(MAX_ENEMIES, 2 + Math.floor((level - 1) * 0.4));
    }

    function load() {
        try {
            var s = JSON.parse(window.localStorage.getItem(KEY));
            if (s && s.level >= 1) {
                state.level = Math.floor(s.level);
                state.xp = Math.max(0, Math.min(s.xp || 0, xpNeeded(state.level) - 1));
            }
        } catch (e) {}
    }

    function save() {
        try { window.localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
    }

    // Add or remove enemies until the count matches the level
    function syncEnemies() {
        var target = enemiesForLevel(state.level);
        while (allEnemies.length < target) { allEnemies.push(new Enemy(true)); }
        while (allEnemies.length > target) { allEnemies.pop(); }
    }

    function updateHud() {
        var need = xpNeeded(state.level);
        var t = document.getElementById('levelText');
        var f = document.getElementById('xpFill');
        var x = document.getElementById('xpText');
        if (t) { t.textContent = 'Level ' + state.level; }
        if (f) { f.style.width = Math.min(100, state.xp / need * 100) + '%'; }
        if (x) { x.textContent = state.xp + ' / ' + need + ' XP'; }
    }

    function addXp(n) {
        var before = state.level;
        state.xp += n;
        while (state.xp >= xpNeeded(state.level)) {
            state.xp -= xpNeeded(state.level);
            state.level++;
            if (window.shop) { shop.addCoins(LEVEL_UP_COINS); }
        }
        if (state.level > before) {
            var gained = state.level - before;
            syncEnemies();
            // every enemy unlocked between the old and the new level (even if several levels were gained at once)
            var changedMap = window.mapSystem && mapSystem.onLevel(state.level);
            if (changedMap) {   // new zone: every enemy gets the new theme right away
                allEnemies.forEach(function(e) { e.type = pickEnemyType(state.level); e.respawn(true); });
            }
            var fresh = unlockedEnemyTypes(state.level).filter(function(t) { return t.minLevel > before && t.minLevel <= state.level; });
            popup = {
                t: POPUP_TIME,
                title: 'LEVEL ' + state.level + '!',
                line1: enemiesForLevel(state.level) + ' enemies  |  +' + (LEVEL_UP_COINS * gained) + ' coins',
                line2: fresh.length ? 'New enemy: ' + fresh.map(function(t) { return enemyName(t, state.level); }).join(', ') : '',
                icon: fresh.length && fresh[fresh.length - 1].sprite ? fresh[fresh.length - 1].sprite : null
            };
            startFx();
            if (window.bossFight) { for (var lv = before + 1; lv <= state.level; lv++) { bossFight.check(lv); } }
        }
        save();
        updateHud();
    }

    // ---------- level-up animation ----------
    var SPARK_COLORS = ['#ffd966', '#ff9f1c', '#ff4d00', '#38d430', '#ffffff'];

    function startFx() {
        // crossing the river calls addXp before the player is sent back, so use the respawn spot then
        var atTop = player.y <= 0;
        var cx = (atTop ? 202 : player.x) + 50, cy = (atTop ? 400 : player.y) + 105;
        fx = { t: 0, dur: FX_TIME, cx: cx, cy: cy };
        sparks = [];
        for (var i = 0; i < 40; i++) {
            var a = Math.random() * Math.PI * 2, sp = 90 + Math.random() * 190;
            sparks.push({
                x: cx, y: cy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 90,
                age: 0, life: 0.7 + Math.random() * 0.8,
                size: 4 + Math.floor(Math.random() * 3) * 2,
                color: SPARK_COLORS[Math.floor(Math.random() * SPARK_COLORS.length)]
            });
        }
    }

    function updateFx(dt) {
        if (!fx) { return; }
        fx.t += dt;
        sparks.forEach(function(p) {
            p.age += dt;
            p.vy += 320 * dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
        });
        sparks = sparks.filter(function(p) { return p.age < p.life; });
        if (fx.t >= fx.dur) { fx = null; sparks = []; }
    }

    function easeOutBack(x) {
        var c1 = 1.70158, c3 = c1 + 1;
        return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
    }

    function renderFx() {
        if (!fx) { return; }
        var t = fx.t;
        var arrow = Resources.get('images/oneup-arrow.png');
        var label = Resources.get('images/oneup-text.png');
        ctx.save();
        ctx.imageSmoothingEnabled = false;

        // 1) quick white flash
        if (t < 0.25) {
            ctx.globalAlpha = 0.55 * (1 - t / 0.25);
            ctx.fillStyle = '#fff';
            ctx.fillRect(0, 0, 505, 606);
        }

        // 2) two expanding golden rings around the player
        for (var r = 0; r < 2; r++) {
            var rt = t - r * 0.18;
            if (rt > 0 && rt < 0.9) {
                ctx.globalAlpha = 1 - rt / 0.9;
                ctx.strokeStyle = r ? '#ff9f1c' : '#ffd966';
                ctx.lineWidth = 8 - rt * 6;
                ctx.beginPath();
                ctx.arc(fx.cx, fx.cy, 20 + rt * 280, 0, Math.PI * 2);
                ctx.stroke();
            }
        }

        // 3) green arrows rising across the board, one per column
        if (arrow) {
            for (var i = 0; i < 5; i++) {
                var at = (t - i * 0.12) / 1.1;
                if (at > 0 && at < 1) {
                    ctx.globalAlpha = at < 0.8 ? 1 : (1 - at) / 0.2;
                    var ay = 580 - at * at * 700 - at * 60;
                    ctx.drawImage(arrow, i * 101 + 50 - arrow.width / 2, ay);
                }
            }
        }

        // 4) square pixel sparks
        sparks.forEach(function(p) {
            ctx.globalAlpha = Math.max(0, 1 - p.age / p.life);
            ctx.fillStyle = p.color;
            ctx.fillRect(Math.round(p.x), Math.round(p.y), p.size, p.size);
        });

        // 5) +1UP: pops in with a bounce, floats up and fades out
        if (label) {
            var pop = Math.min(1, t / 0.35);
            var scale = 0.2 + 0.8 * easeOutBack(pop);
            var w = label.width * scale, h = label.height * scale;
            var x = Math.max(8, Math.min(505 - w - 8, fx.cx - w / 2));
            var y = Math.max(8, fx.cy - 90 - t * 45 - h / 2);
            ctx.globalAlpha = t > fx.dur - 0.5 ? Math.max(0, (fx.dur - t) / 0.5) : 1;
            ctx.drawImage(label, x, y, w, h);
        }
        ctx.restore();
    }

    function update(dt) {
        updateFx(dt);
        if (popup) {
            popup.t -= dt;
            if (popup.t <= 0) { popup = null; }
        }
    }

    function render() {
        renderFx();
        if (!popup) { return; }
        var fade = Math.min(1, popup.t / 0.4);
        ctx.globalAlpha = fade;
        ctx.fillStyle = 'rgba(20, 20, 30, 0.85)';
        ctx.fillRect(52, 120, 401, 100);
        ctx.strokeStyle = '#ffd966';
        ctx.lineWidth = 4;
        ctx.strokeRect(52, 120, 401, 100);
        ctx.textAlign = 'center';
        ctx.fillStyle = '#ffd966';
        ctx.font = 'bold 28px Arial';
        ctx.fillText(popup.title, 252, 158);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 16px Arial';
        ctx.fillText(popup.line1, 252, 186);
        if (popup.line2) {
            ctx.fillStyle = '#ff8a8a';
            ctx.fillText(popup.line2, 252, 208);
        }
        var icon = popup.icon && Resources.get(popup.icon);
        if (icon) { ctx.drawImage(icon, 392, 98, 61, 103); }   // preview of the new enemy
        ctx.globalAlpha = 1;
        ctx.textAlign = 'start';
    }

    // Called when you die: back to level 1 with 0 XP (coins, characters and rewards stay)
    function reset() {
        state.level = 1;
        state.xp = 0;
        popup = null; fx = null; sparks = [];
        if (window.mapSystem) { mapSystem.onLevel(1, true); }   // back to the first map
        syncEnemies();
        allEnemies.forEach(function(e) { e.type = pickEnemyType(1); e.respawn(true); });
        save();
        updateHud();
    }

    load();
    if (window.mapSystem) { mapSystem.onLevel(state.level, true); }   // start in the map that matches the saved level
    syncEnemies();
    updateHud();

    return {
        reset: reset,
        get level() { return state.level; },
        xpPerCrossing: XP_PER_CROSSING,
        xpPerLootbox: XP_PER_LOOTBOX,
        enemiesForLevel: enemiesForLevel,
        speedMult: function() { return Math.min(1.35, 1 + 0.015 * (state.level - 1)); },
        addXp: addXp,
        update: update,
        render: render
    };
})();
