
function selectPlayer(){
    // Cycles through the characters you own (see js/shop.js)
    if (window.shop) { shop.cycle(); }
};



// Enemies our player must avoid (types are defined in enemies.js)
var LANES = [68, 151, 234];
var MIN_SPEED = 100, MAX_BASE_SPEED = 300;   // px/s antes dos multiplicadores
var SPEED_CAP = 440;                          // nenhum bicho passa disso (exceto o dash do Charger)
var DASH_CAP = 560;

var Enemy = function(spread) {
    var lvl = window.levelSystem ? levelSystem.level : 1;
    this.type = pickEnemyType(lvl);
    this.sprite = 'images/enemy-bug.png';
    this.respawn(spread);
};

Enemy.prototype.respawn = function(spread) {
    var mult = window.levelSystem ? levelSystem.speedMult() : 1;
    this.dir = this.type.reverse ? -1 : 1;
    // 'spread' scatters new enemies so they don't all start together
    var offset = spread ? Math.random() * 450 : 0;
    this.x = this.dir === 1 ? -100 - offset : 505 + offset;
    this.y = LANES[Math.floor(Math.random() * 3)];
    var base = MIN_SPEED + Math.random() * (MAX_BASE_SPEED - MIN_SPEED);
    this.speed = Math.min(SPEED_CAP, base * this.type.speed * mult);
    this.laneTimer = 1.5 + Math.random() * 1.5;   // zigzag: time until lane change
    this.warn = false;
    this.phase = 'cruise';                        // charger: cruise -> wind -> dash
    this.phaseTime = 0;
    this.stopX = 60 + Math.random() * 300;
    this.shake = 0;
    if (this.seed === undefined) { this.seed = Math.random() * 10; }   // desynchronises the animations
};

Enemy.prototype.update = function(dt) {

    // Loot box effects: frozen = stopped and harmless, slow-mo = 40% speed
    var frozen = player.freezeTime > 0;
    var factor = frozen ? 0 : (player.slowTime > 0 ? 0.4 : 1);
    this.frozen = frozen;

    var speed = this.speed;
    this.shake = 0;

    var changesLane = this.type.id === 'zigzag' || this.type.id === 'reaper';
    if (changesLane && !frozen) {
        this.laneTimer -= dt * (player.slowTime > 0 ? 0.4 : 1);
        this.warn = this.laneTimer < 0.5;          // blinks just before switching lanes
        if (this.laneTimer <= 0) {
            var old = this.y;
            if (this.type.id === 'reaper' && LANES.indexOf(player.y) !== -1) {
                this.y = player.y;                      // the Reaper jumps to YOUR lane
            } else {
                while (this.y === old) { this.y = LANES[Math.floor(Math.random() * 3)]; }
            }
            this.laneTimer = (this.type.id === 'reaper' ? 2.2 : 1.5) + Math.random() * 1.5;
            this.warn = false;
        }
    }

    if (this.type.id === 'charger') {
        if (this.phase === 'cruise' && this.x >= this.stopX) {
            this.phase = 'wind';
            this.phaseTime = 0.8;
        }
        if (this.phase === 'wind') {
            speed = 0;
            this.shake = 3;                        // trembles, then dashes
            this.phaseTime -= dt * factor;
            if (this.phaseTime <= 0) { this.phase = 'dash'; }
        } else if (this.phase === 'dash') {
            speed = Math.min(this.speed * 4, DASH_CAP);
        }
    }

    this.x += speed * dt * factor * this.dir;

    var gone = this.dir === 1 ? this.x >= 505 : this.x <= -100;
    if (gone) {
        // pick a fresh type each lap, so newly unlocked enemies show up quickly
        this.type = pickEnemyType(window.levelSystem ? levelSystem.level : 1);
        this.respawn(false);
    }

    if(!frozen && (Math.floor(this.x+60) >= player.x) && (Math.floor(this.x-40) <= player.x) && (this.y === player.y)){
        var hitX = player.x + 50, hitY = player.y + 110;   // onde o jogador foi atingido
        player.reset();
        if (player.shield > 0) {
            // The shield absorbs the hit
            player.shield--;
            if (window.fx) { fx.hit(hitX, hitY, true); }
        } else {
            player.won.pop();
            if (window.fx) { fx.hit(hitX, hitY, false); }
            if (window.gameEnd) { gameEnd.loseLife(); }
        }
    }
};


// Draw the enemy on the screen, required method for game.
// Every monster type has its own little animation (visual only, hitboxes don't change).
Enemy.prototype.render = function() {
    var img = getEnemySprite(this.type);
    if (!img) { return; }

    var visible = !this.warn || Math.floor(Date.now() / 80) % 2 === 0;
    if (!visible) { return; }

    var id = this.type.id;
    var t = Date.now() / 1000 + (this.seed || 0);
    var frozen = !!this.frozen;
    var dx = this.x + (this.shake ? (Math.random() - 0.5) * this.shake * 2 : 0);
    var dy = 0, rot = 0, sx = 1, sy = 1, alpha = frozen ? 0.45 : 1;

    if (!frozen) {
        if (id === 'dragon') {                         // flaps: bobs, tilts and stretches with each wing beat
            var flap = Math.sin(t * 9);
            dy = flap * 5 - 4; rot = flap * 0.06; sy = 1 + flap * 0.05; sx = 1 - flap * 0.03;
        } else if (id === 'reaper') {                  // floats and fades in and out like a ghost
            dy = Math.sin(t * 2.4) * 6 - 6; rot = Math.sin(t * 1.6) * 0.04;
            alpha = 0.75 + 0.25 * Math.sin(t * 3);
        } else if (id === 'zigzag') {                  // sways from side to side
            rot = Math.sin(t * 8) * 0.12; dy = -Math.abs(Math.sin(t * 8)) * 3;
        } else if (id === 'speeder') {                 // leans forward and skitters
            rot = 0.1; dy = Math.sin(t * 22) * 1.5; sx = 1.05; sy = 0.96;
        } else if (id === 'charger') {
            if (this.phase === 'wind') {               // crouches while it trembles
                sy = 0.9; sx = 1.08; rot = -0.05;
            } else if (this.phase === 'dash') {        // stretches out while dashing
                sx = 1.12; sy = 0.92; rot = 0.08;
            } else {
                dy = Math.abs(Math.sin(t * 7)) * -3;
            }
        } else {                                       // bug, backtrack: scuttling hop + little squash
            var hop = Math.abs(Math.sin(t * 10));
            dy = -hop * 4; sy = 1 + hop * 0.05; sx = 1 - hop * 0.03; rot = Math.sin(t * 10) * 0.03;
        }
    }

    var cx = 50, cy = 120;                              // pivot near the middle of the sprite
    var flying = id === 'dragon' || id === 'reaper';

    ctx.save();
    ctx.imageSmoothingEnabled = false;

    // soft ground shadow (smaller when the monster is up in the air)
    if (!frozen) {
        var lift = Math.min(1, Math.max(0, -dy) / 12);
        ctx.globalAlpha = (flying ? 0.28 : 0.2) * (1 - 0.4 * lift);
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.ellipse(dx + 50, this.y + 138, 34 - lift * 8, 7 - lift * 2, 0, 0, Math.PI * 2);
        ctx.fill();
    }

    // speed streaks behind fast / dashing monsters
    if (!frozen && (id === 'speeder' || (id === 'charger' && this.phase === 'dash'))) {
        ctx.fillStyle = id === 'speeder' ? '#9fc3ff' : '#ffe27a';
        for (var i = 0; i < 3; i++) {
            ctx.globalAlpha = 0.35 - i * 0.08;
            ctx.fillRect(this.dir === 1 ? dx - 28 - i * 14 : dx + 118 + i * 14, this.y + 98 + i * 14, 24, 3);
        }
    }

    // reaper aura
    if (id === 'reaper' && !frozen) {
        ctx.globalAlpha = 0.18 + 0.1 * Math.sin(t * 3);
        ctx.fillStyle = '#7a2cff';
        ctx.beginPath();
        ctx.arc(dx + cx, this.y + cy + dy, 46, 0, Math.PI * 2);
        ctx.fill();
    }

    ctx.globalAlpha = alpha;
    ctx.translate(dx + cx, this.y + cy + dy);
    if (this.dir === -1) { ctx.scale(-1, 1); }
    ctx.rotate(rot * this.dir);
    ctx.scale(sx, sy);
    ctx.drawImage(img, -cx, -cy);
    ctx.restore();
    ctx.globalAlpha = 1;
};



// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.
var Player = function(x,y) {
//console.log(selectedPlayer);
    this.x = x;
    this.y = y;
    //this.allPlayers = ['images/char-boy.png','images/char-cat-girl.png', 'images/char-horn-girl.png'];
    this.player = 1;
    this.sprite = 'images/char-boy.png';
    this.animTime = 0;
    this.animFrame = 0;
    this.facing = 'front';
    this.moving = false;
    this.moveTimer = 0;
    //this.player++;
    this.star = 'images/Star.png';
    this.won = [];
    this.score = 0;
    this.shield = 0;      // batidas que o escudo ainda absorve
    this.slowTime = 0;    // segundos de câmera lenta restantes
    this.freezeTime = 0;  // segundos de insetos congelados restantes
};

Player.prototype.update = function(dt) {
    dt = dt || 0;
    this.slowTime = Math.max(0, this.slowTime - dt);
    this.animTime += dt || 0;
    if (this.moveTimer > 0) {
        this.moveTimer -= dt || 0;
        if (this.moveTimer <= 0) { this.moving = false; this.animFrame = 0; }
    }
    // walk cycle only while moving (3 frames per direction)
    if (this.moving && this.animTime >= 0.1) { this.animTime = 0; this.animFrame = (this.animFrame + 1) % 3; }
    this.freezeTime = Math.max(0, this.freezeTime - dt);

    if (window.gameEnd) { gameEnd.check(); }

    var result = document.getElementById('score');
    result.innerHTML = ('Score ' + this.score);

    var fx = [];
    if (this.shield > 0) fx.push('Shield x' + this.shield);
    if (this.slowTime > 0) fx.push('Slow-mo ' + Math.ceil(this.slowTime) + 's');
    if (this.freezeTime > 0) fx.push('Frozen bugs ' + Math.ceil(this.freezeTime) + 's');
    var el = document.getElementById('effects');
    if (el) {
        el.innerHTML = 'Loot boxes opened: ' + (window.lootBox ? lootBox.opened : 0) +
            (fx.length ? ' &nbsp;|&nbsp; ' + fx.join(' &nbsp;|&nbsp; ') : '');
    }
};

Player.prototype.win = function() {   
    this.won.push('');
    if (window.shop) { shop.addCoins(shop.coinsPerCrossing); }
    if (window.rewards) { rewards.track('cross'); }
    if (window.levelSystem) { levelSystem.addXp(levelSystem.xpPerCrossing); }
    if (this.won.length === 5) {
    	this.score ++;
    	this.won.length = 0;
    }

};

Player.prototype.reset = function() {
    this.x = 202;
    this.y = 400;
};

// Animated characters (sprite sheets from images/chars, see shop.js): the walk cycle
// plays while moving; standing still they breathe (and blink when facing you).
Player.prototype.renderSheet = function(def, img) {
    var dir = { front: 'down', back: 'up', left: 'left', right: 'right' }[this.facing] || 'down';
    var n = def.sheet[dir] || 1;
    var t = Date.now() / 1000;
    var frame = 0, hop = 0, squash = 1, tilt = 0;
    if (this.moving) {
        frame = Math.floor(t * 10) % n;
        hop = -Math.abs(Math.sin(t * 20)) * 5;
        if (n === 1) { tilt = Math.sin(t * 22) * 0.12; }     // one-frame characters waddle instead
    } else {
        if (n > 1 && (dir === 'down' || dir === 'up')) { frame = Math.floor(t * 3) % n; }
        squash = 1 + Math.sin(t * 3) * 0.025;
    }
    ctx.save();
    ctx.translate(this.x + 50.5, this.y + 146);          // feet of the character
    ctx.rotate(tilt);
    ctx.scale(1 / squash, squash);
    ctx.drawImage(img, frame * 101, { down: 0, left: 1, right: 2, up: 3 }[dir] * 171, 101, 171,
                  -50.5, -146 + hop, 101, 171);
    ctx.restore();
};

Player.prototype.render = function() {
        // depois de levar dano o jogador pisca (translúcido / normal) por 1 segundo
        var blink = this.hurtTime > 0 && Math.floor(Date.now() / 90) % 2 === 0;
        if (blink) { ctx.save(); ctx.globalAlpha = 0.3; }
        this.renderBody();
        if (blink) { ctx.restore(); }
        this.renderStars();
};

Player.prototype.renderBody = function() {
        var sprite = Resources.get(this.sprite);
        if (this.charDef && this.charDef.sheet && sprite) {
            this.renderSheet(this.charDef, sprite);
        } else if (this.sprite.indexOf('images/snorlax/frame-') === 0) {
            var frameIndex = this.facing === 'back' ? 9 + this.animFrame :
                (this.facing === 'left' ? 3 + this.animFrame :
                (this.facing === 'right' ? 6 + this.animFrame : this.animFrame));
            sprite = Resources.get('images/snorlax/frame-' + frameIndex + '.png') || sprite;
            if (sprite) {
                // frames are 316x384: keep the proportions, feet on the tile
                var bob = Math.sin(Date.now()/180) * 1.5;
                ctx.drawImage(sprite, this.x + 6, this.y + 39 + bob, 88, 107);
            }
        } else if (sprite) {
            var bounce = this.moving ? Math.sin(Date.now()/55)*2 : 0;
            ctx.drawImage(sprite, this.x, this.y + bounce);
        }
};

Player.prototype.renderStars = function() {
        if (this.won.length > 0){
            var x = 0;
            for (var i in this.won){
                ctx.drawImage(Resources.get(this.star), x , -10);
                x += 101;
            }
        }
};

Player.prototype.selectPlayer = function() { 
    var x = 101;
    console.log("in selectPlayer");
    console.log(this.allPlayers[0]);
    for(var player = 0; player < this.allPlayers.length; player++) {
        console.log(this.allPlayers[player]);
        Resources.load(this.allPlayers[player]);
        ctx.drawImage(Resources.get(this.allPlayers[player]), x, 200);
        x += 101;
    } 
    sleep(1000);
    this.sprite = 'images/char-cat-girl.png';       
};

Player.prototype.handleInput = function(keyCode) {
    if (window.shop && shop.isOpen()) { return; }
    if (window.gameMenu && gameMenu.isOpen()) { return; }
    if (window.profile && profile.isOpen()) { return; }
    if (window.bossFight && bossFight.isOpen()) { return; }
    if (window.gameEnd && gameEnd.isOver()) { return; }
    var faces = { up: 'back', down: 'front', left: 'left', right: 'right' };
    if (faces[keyCode]) {
        this.facing = faces[keyCode];
        this.moving = true;
        this.moveTimer = 0.3;
    }
    if (keyCode === 'up')
        this.y -= 83;
    if (keyCode === 'down')
        this.y += 83;
    if (keyCode === 'right')
        this.x += 101;
    if (keyCode === 'left')
        this.x -= 101;
    if(this.x <= 0)
        this.x = 0;
    if(this.x >= 404)
        this.x = 404;
    if(this.y >= 400 )
       this.y = 400;
    if(this.y <= 0 ){
        this.win();
        this.reset();
    }
};
// Now instantiate your objects.
// Place all enemy objects in an array called allEnemies
// Place the player object in a variable called player

var player = new Player(202,400);
//var allEnemies = [new Enemy() ];

// Enemies are added/removed automatically by the level system (level.js)
var allEnemies = [];

// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down',
        65: 'left',   // A
        87: 'up',     // W
        68: 'right',  // D
        83: 'down'    // S
    };
    if (e.ctrlKey || e.metaKey || e.altKey) { return; }
    player.handleInput(allowedKeys[e.keyCode]);
});
