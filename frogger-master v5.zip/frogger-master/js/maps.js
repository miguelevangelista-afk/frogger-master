/* maps.js
 * Themed maps. The map follows your level (like an RPG zone): each map unlocks at a level,
 * has its own tiles and its own enemy "skins" (name + colour), and some enemies only live in certain maps.
 *
 * To add a map: add an entry to MAPS (and its 3 tile images). To tune: change minLevel.
 *   skins : per enemy id -> { name, tint } override (tint null = original sprite colours)
 *
 * Depends on: ctx (engine.js). Used by: engine.js (tiles), enemies.js (skins/filter), level.js (level-up hook).
 */
var mapSystem = (function() {

    var MAPS = [
        { id: 'forest',  name: 'Forest',  minLevel: 1,
          tiles: { water: 'images/water-block.png', stone: 'images/stone-block.png', grass: 'images/grass-block.png' },
          skins: {} },
        { id: 'desert',  name: 'Desert',  minLevel: 10,
          tiles: { water: 'images/maps/desert-water.png', stone: 'images/maps/desert-stone.png', grass: 'images/maps/desert-grass.png' },
          skins: {
              bug:     { name: 'Scorpion',   tint: '#e0902a' },
              speeder: { name: 'Sand Viper', tint: '#d6c24a' },
              zigzag:  { name: 'Scarab',     tint: '#3fae6b' },
              charger: { name: 'Mummy',      tint: '#cfc6a0' },
              reverse: { name: 'Sandworm',   tint: '#a86a3a' }
          } },
        { id: 'snow',    name: 'Snowfield', minLevel: 20,
          tiles: { water: 'images/maps/snow-water.png', stone: 'images/maps/snow-stone.png', grass: 'images/maps/snow-grass.png' },
          skins: {
              bug:     { name: 'Ice Crab',   tint: '#8fd8ff' },
              speeder: { name: 'Snow Wolf',  tint: '#e8f3ff' },
              zigzag:  { name: 'Frost Imp',  tint: '#6a8cff' },
              charger: { name: 'Yeti',       tint: '#ffffff' },
              reverse: { name: 'Ice Golem',  tint: '#35b8d6' }
          } },
        { id: 'volcano', name: 'Volcano', minLevel: 35,
          tiles: { water: 'images/maps/volcano-water.png', stone: 'images/maps/volcano-stone.png', grass: 'images/maps/volcano-grass.png' },
          skins: {
              bug:     { name: 'Magma Bug',  tint: '#ff5a1f' },
              speeder: { name: 'Fire Fly',   tint: '#ffb000' },
              zigzag:  { name: 'Ember',      tint: '#ff2a2a' },
              charger: { name: 'Lava Brute', tint: '#8a1500' },
              reverse: { name: 'Ash Crawler', tint: '#6f6378' }
          } }
    ];

    var banner = null;     // "NEW MAP" announcement
    var shownId = null;    // map the player is currently in (to detect a change)

    function forLevel(level) {
        var found = MAPS[0];
        for (var i = 0; i < MAPS.length; i++) { if (level >= MAPS[i].minLevel) { found = MAPS[i]; } }
        return found;
    }
    function currentLevel() { return window.levelSystem ? levelSystem.level : 1; }
    function current() { return forLevel(currentLevel()); }

    // Tile image for a row type ('water' | 'stone' | 'grass') in the current map
    function tile(kind) { return current().tiles[kind]; }

    // Skin (name/tint) for an enemy type id in a given map
    function skin(mapObj, typeId) { return (mapObj && mapObj.skins[typeId]) || null; }

    // Call after the level changes (level-up or reset). Returns true if the map changed.
    function onLevel(level, silent) {
        var m = forLevel(level);
        if (shownId === null) { shownId = m.id; return false; }     // first call = initial state
        if (m.id === shownId) { return false; }
        shownId = m.id;
        if (!silent) { banner = { t: 3.2, name: m.name }; }
        return true;
    }

    function update(dt) { if (banner) { banner.t -= dt; if (banner.t <= 0) { banner = null; } } }

    function render() {
        if (!banner) { return; }
        var a = Math.min(1, banner.t / 0.5, (3.2 - banner.t) / 0.3 + 0.001);
        ctx.save();
        ctx.globalAlpha = Math.max(0, a);
        ctx.fillStyle = 'rgba(20, 20, 30, 0.85)';
        ctx.fillRect(52, 260, 401, 80);
        ctx.strokeStyle = '#38d430';
        ctx.lineWidth = 4;
        ctx.strokeRect(52, 260, 401, 80);
        ctx.textAlign = 'center';
        ctx.fillStyle = '#9fe8a0';
        ctx.font = 'bold 16px Arial';
        ctx.fillText('NEW MAP', 252, 290);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 28px Arial';
        ctx.fillText(banner.name, 252, 324);
        ctx.restore();
    }

    return {
        MAPS: MAPS,
        forLevel: forLevel,
        current: current,
        tile: tile,
        skin: skin,
        onLevel: onLevel,
        update: update,
        render: render,
        tileImages: (function() {
            var l = [];
            MAPS.forEach(function(m) { for (var k in m.tiles) { if (l.indexOf(m.tiles[k]) < 0) { l.push(m.tiles[k]); } } });
            return l;
        })()
    };
})();
